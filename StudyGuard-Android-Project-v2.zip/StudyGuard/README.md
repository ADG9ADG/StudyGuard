# StudyGuard

A phone-first Android prototype that attempts to block Instagram Reels and YouTube Shorts during a timed focus session while leaving other app content available.

## Important limitations

- This is a best-effort prototype, not a guaranteed content filter.
- Instagram and YouTube do not expose public APIs for blocking only Reels or Shorts.
- The accessibility service uses visible text heuristics and the Android Back action. App interface changes can break detection, and some false positives/false negatives are possible.
- The service does not read message contents for storage, capture screenshots, or transmit screen content.
- The app has no server and no analytics SDK.
- Accessibility permission must be enabled manually by the device owner.

## Build an APK using only your Android phone

This project includes a GitHub Actions workflow to build the APK in the cloud.

1. Install a browser and sign in to GitHub.
2. Create a new **private** GitHub repository named `StudyGuard`.
3. Upload the contents of this ZIP to the repository (extract the ZIP first; upload the files and folders inside it).
4. Open the repository's **Actions** tab and enable Actions if prompted.
5. Select **Build StudyGuard APK** and tap **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `StudyGuard-debug-apk`.
8. Extract the downloaded artifact and tap `app-debug.apk` to install. Android may ask you to allow installation from that browser or file manager.

## First launch

1. Open StudyGuard.
2. Tap **Enable StudyGuard accessibility service**.
3. In Android Settings > Accessibility > Downloaded apps / Installed apps, enable **StudyGuard content blocker**.
4. Return to StudyGuard and start a 25-minute test session.
5. Test a Shorts screen and a Reels screen. Also verify that normal videos, posts and messages remain usable.

## Build locally

Use Android Studio with JDK 17 and Android SDK 35, then run the `assembleDebug` Gradle task. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Permissions

The only special permission is the user-enabled Android Accessibility Service. It is used to inspect visible accessibility labels in Instagram and YouTube and navigate back from likely short-video feeds during an active timer.
