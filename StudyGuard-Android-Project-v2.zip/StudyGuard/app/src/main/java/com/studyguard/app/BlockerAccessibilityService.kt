package com.studyguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Best-effort text detector. Detection is intentionally limited to the selected
 * app and only runs during a focus session when that app's switch is enabled.
 */
class BlockerAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !FocusPrefs.isFocusActive(this)) return

        val pkg = event.packageName?.toString() ?: return
        val isInstagram = pkg == "com.instagram.android"
        val isYouTube = pkg == "com.google.android.youtube"
        if (!isInstagram && !isYouTube) return
        if (isInstagram && !FocusPrefs.instagramEnabled(this)) return
        if (isYouTube && !FocusPrefs.youtubeEnabled(this)) return

        val root = rootInActiveWindow ?: return
        val visibleText = buildString { collectText(root, this, 0) }.lowercase()

        val likelyReels = isInstagram &&
            visibleText.contains("reels") &&
            (visibleText.contains("original audio") || visibleText.contains("audio") ||
             (visibleText.contains("comments") && visibleText.contains("send")))

        val likelyShorts = isYouTube &&
            visibleText.contains("shorts") &&
            (visibleText.contains("comments") || visibleText.contains("subscribe") ||
             visibleText.contains("dislike"))

        if (likelyReels || likelyShorts) {
            val now = System.currentTimeMillis()
            if (now - lastBlockedAt > 1800L) {
                lastBlockedAt = now
                FocusPrefs.addBlocked(this)
                Toast.makeText(
                    this,
                    if (likelyReels) "Reels blocked — back to your studies!" else "Shorts blocked — back to your studies!",
                    Toast.LENGTH_SHORT
                ).show()
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 18) return
        node.text?.let { out.append(it).append(' ') }
        node.contentDescription?.let { out.append(it).append(' ') }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() = Unit
}
