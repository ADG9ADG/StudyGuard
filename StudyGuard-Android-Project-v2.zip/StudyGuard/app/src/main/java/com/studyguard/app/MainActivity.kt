package com.studyguard.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

private enum class Page { HOME, BLOCKERS, FOCUS, REPORTS, SETTINGS }
private enum class BlockerPage { INSTAGRAM, YOUTUBE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyGuardApp() }
    }
}

@Composable
private fun StudyGuardApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf(Page.HOME) }
    var blockerPage by remember { mutableStateOf(BlockerPage.INSTAGRAM) }
    var refresh by remember { mutableIntStateOf(0) }
    var endTime by remember { mutableLongStateOf(FocusPrefs.endTime(context)) }
    var selectedMinutes by remember { mutableIntStateOf(45) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var blocked by remember { mutableIntStateOf(FocusPrefs.blockedCount(context)) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            endTime = FocusPrefs.endTime(context)
            blocked = FocusPrefs.blockedCount(context)
            if (endTime > 0L && now >= endTime) {
                FocusPrefs.stop(context)
                endTime = 0L
            }
            delay(1000)
        }
    }

    val active = endTime > now
    val remaining = (endTime - now).coerceAtLeast(0L)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(remaining)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(remaining) % 60
    val instagramOn = remember(refresh) { FocusPrefs.instagramEnabled(context) }
    val youtubeOn = remember(refresh) { FocusPrefs.youtubeEnabled(context) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF202124),
            onPrimary = Color.White,
            background = Color(0xFFF5F6F7),
            surface = Color.White,
            secondary = Color(0xFF666B73)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = page == Page.HOME, onClick = { page = Page.HOME },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = page == Page.BLOCKERS, onClick = { page = Page.BLOCKERS },
                        icon = { Icon(Icons.Default.Lock, null) }, label = { Text("Blockers") })
                    NavigationBarItem(selected = page == Page.FOCUS, onClick = { page = Page.FOCUS },
                        icon = { Icon(Icons.Default.Timer, null) }, label = { Text("Focus") })
                    NavigationBarItem(selected = page == Page.REPORTS, onClick = { page = Page.REPORTS },
                        icon = { Icon(Icons.Default.BarChart, null) }, label = { Text("Reports") })
                    NavigationBarItem(selected = page == Page.SETTINGS, onClick = { page = Page.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("STUDYGUARD", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        Text(pageTitle(page), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    }
                    Surface(shape = RoundedCornerShape(50), color = Color(0xFFE8E9EB)) {
                        Text("2.0", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontWeight = FontWeight.SemiBold)
                    }
                }

                when (page) {
                    Page.HOME -> HomePage(active, minutes, seconds, instagramOn, youtubeOn, blocked,
                        onFocus = { page = Page.FOCUS },
                        onInstagram = { blockerPage = BlockerPage.INSTAGRAM; page = Page.BLOCKERS },
                        onYoutube = { blockerPage = BlockerPage.YOUTUBE; page = Page.BLOCKERS })
                    Page.BLOCKERS -> BlockersPage(
                        selected = blockerPage,
                        instagramOn = instagramOn,
                        youtubeOn = youtubeOn,
                        onSelect = { blockerPage = it },
                        onInstagramToggle = { FocusPrefs.setInstagramEnabled(context, it); refresh++ },
                        onYoutubeToggle = { FocusPrefs.setYoutubeEnabled(context, it); refresh++ },
                        onAccessibility = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    )
                    Page.FOCUS -> FocusPage(active, minutes, seconds, selectedMinutes,
                        onSelectMinutes = { selectedMinutes = it },
                        onStart = { FocusPrefs.start(context, selectedMinutes); endTime = FocusPrefs.endTime(context) },
                        onStop = { FocusPrefs.stop(context); endTime = 0L })
                    Page.REPORTS -> ReportsPage(blocked, instagramOn, youtubeOn)
                    Page.SETTINGS -> SettingsPage(
                        onAccessibility = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    )
                }
            }
        }
    }
}

private fun pageTitle(page: Page) = when (page) {
    Page.HOME -> "Your focus, protected."
    Page.BLOCKERS -> "Distraction blockers"
    Page.FOCUS -> "Focus session"
    Page.REPORTS -> "Your progress"
    Page.SETTINGS -> "App settings"
}

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@Composable
private fun HomePage(
    active: Boolean, mins: Long, secs: Long, instagramOn: Boolean, youtubeOn: Boolean, blocked: Int,
    onFocus: () -> Unit, onInstagram: () -> Unit, onYoutube: () -> Unit
) {
    Panel {
        Text(if (active) "FOCUS SESSION ACTIVE" else "READY WHEN YOU ARE", style = MaterialTheme.typography.labelLarge)
        Text(if (active) "%02d:%02d".format(mins, secs) else "Start a focus session",
            style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(if (active) "Your selected blockers are protecting your session." else "Choose a duration and keep distractions away.",
            color = MaterialTheme.colorScheme.secondary)
        Button(onClick = onFocus, modifier = Modifier.fillMaxWidth()) { Text(if (active) "View focus session" else "Set up focus session") }
    }
    Text("YOUR BLOCKERS", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    Panel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Instagram Reels", fontWeight = FontWeight.SemiBold); Text(if (instagramOn) "Blocker enabled" else "Blocker disabled", color = MaterialTheme.colorScheme.secondary) }
            TextButton(onClick = onInstagram) { Text("Manage") }
        }
        HorizontalDivider()
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("YouTube Shorts", fontWeight = FontWeight.SemiBold); Text(if (youtubeOn) "Blocker enabled" else "Blocker disabled", color = MaterialTheme.colorScheme.secondary) }
            TextButton(onClick = onYoutube) { Text("Manage") }
        }
    }
    Panel {
        Text("BLOCKS RECORDED", style = MaterialTheme.typography.labelLarge)
        Text("$blocked", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Likely Reels or Shorts screens blocked on this device.")
    }
}

@Composable
private fun BlockersPage(
    selected: BlockerPage, instagramOn: Boolean, youtubeOn: Boolean,
    onSelect: (BlockerPage) -> Unit, onInstagramToggle: (Boolean) -> Unit,
    onYoutubeToggle: (Boolean) -> Unit, onAccessibility: () -> Unit
) {
    Text("Manage each app independently. Changes apply immediately.", color = MaterialTheme.colorScheme.secondary)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected == BlockerPage.INSTAGRAM, { onSelect(BlockerPage.INSTAGRAM) }, label = { Text("Instagram") })
        FilterChip(selected == BlockerPage.YOUTUBE, { onSelect(BlockerPage.YOUTUBE) }, label = { Text("YouTube") })
    }
    if (selected == BlockerPage.INSTAGRAM) {
        Panel {
            Text("📸  INSTAGRAM REELS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Control Reels blocking without changing your YouTube settings.")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Reels blocker", fontWeight = FontWeight.SemiBold)
                    Text(if (instagramOn) "Enabled during focus sessions" else "Currently disabled", color = MaterialTheme.colorScheme.secondary)
                }
                Switch(checked = instagramOn, onCheckedChange = onInstagramToggle)
            }
            HorizontalDivider()
            Text("Normal Instagram posts and messages are intended to remain available.", style = MaterialTheme.typography.bodySmall)
        }
    } else {
        Panel {
            Text("▶  YOUTUBE SHORTS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Control Shorts blocking without changing your Instagram settings.")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Shorts blocker", fontWeight = FontWeight.SemiBold)
                    Text(if (youtubeOn) "Enabled during focus sessions" else "Currently disabled", color = MaterialTheme.colorScheme.secondary)
                }
                Switch(checked = youtubeOn, onCheckedChange = onYoutubeToggle)
            }
            HorizontalDivider()
            Text("Regular YouTube videos are intended to remain available.", style = MaterialTheme.typography.bodySmall)
        }
    }
    Panel {
        Text("Required Android permission", fontWeight = FontWeight.SemiBold)
        Text("Enable StudyGuard's accessibility service so it can detect likely Reels and Shorts screens.")
        OutlinedButton(onClick = onAccessibility, modifier = Modifier.fillMaxWidth()) { Text("Open Accessibility settings") }
    }
    Text("Detection is best-effort. App interface changes can affect accuracy. Screen text is processed on-device and is not uploaded.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
}

@Composable
private fun FocusPage(
    active: Boolean, mins: Long, secs: Long, selectedMinutes: Int,
    onSelectMinutes: (Int) -> Unit, onStart: () -> Unit, onStop: () -> Unit
) {
    Panel {
        Text(if (active) "SESSION IN PROGRESS" else "CHOOSE YOUR SESSION", style = MaterialTheme.typography.labelLarge)
        Text(if (active) "%02d:%02d".format(mins, secs) else "Ready to focus?",
            style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Text(if (active) "Selected blockers are active according to their individual switches." else "Choose a duration. Blocking starts with the session.")
        if (active) {
            Button(onClick = onStop, modifier = Modifier.fillMaxWidth()) { Text("End focus session") }
        } else {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(25, 45, 60, 90, 120).forEach { value ->
                    FilterChip(selectedMinutes == value, { onSelectMinutes(value) }, label = { Text("$value min") })
                }
            }
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Start $selectedMinutes-minute session") }
        }
    }
    Text("Tip: keep StudyGuard's accessibility service enabled for blocking to work.", color = MaterialTheme.colorScheme.secondary)
}

@Composable
private fun ReportsPage(blocked: Int, instagramOn: Boolean, youtubeOn: Boolean) {
    Panel {
        Text("TOTAL BLOCKS RECORDED", style = MaterialTheme.typography.labelLarge)
        Text("$blocked", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Text("Count is stored on this device.")
    }
    Panel {
        Text("BLOCKER SETTINGS", fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Instagram Reels"); Text(if (instagramOn) "Enabled" else "Disabled") }
        HorizontalDivider()
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("YouTube Shorts"); Text(if (youtubeOn) "Enabled" else "Disabled") }
    }
    Text("Detailed daily and weekly usage charts are not included in this build yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
}

@Composable
private fun SettingsPage(onAccessibility: () -> Unit) {
    Panel {
        Text("Permissions", fontWeight = FontWeight.SemiBold)
        Text("StudyGuard needs its accessibility service enabled to detect supported distraction screens.")
        OutlinedButton(onClick = onAccessibility, modifier = Modifier.fillMaxWidth()) { Text("Manage accessibility permission") }
    }
    Panel {
        Text("Privacy", fontWeight = FontWeight.SemiBold)
        Text("The blocker reads visible accessibility text on-device. It does not upload screen content.")
    }
    Panel {
        Text("About StudyGuard", fontWeight = FontWeight.SemiBold)
        Text("Version 2.0 • Independent Instagram and YouTube blocker controls")
    }
}
