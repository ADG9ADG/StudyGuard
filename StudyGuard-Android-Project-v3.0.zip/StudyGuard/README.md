# StudyGuard 3.0

A local-first Android focus helper with independent Instagram Reels and YouTube Shorts blockers.

## What is new in 3.0
- Refreshed five-section navigation: Home, Blockers, Focus, Insights, Settings.
- Independent Instagram and YouTube blocker switches; blockers do not require a running focus timer.
- Timed Strict Mode locks the blocker switches until the selected focus timer ends. An Emergency Exit is available in Settings.
- Payment Mode pauses StudyGuard's blocking actions.
- Settings includes a shortcut to Android Accessibility Settings for banking/UPI compatibility troubleshooting.

## Important UPI limitation
Payment Mode pauses StudyGuard's blocker actions, but it does not disable the Android Accessibility Service itself. Some UPI/banking apps may reject any enabled Accessibility Service regardless of whether it is actively blocking. If that happens, turn on Payment Mode, open Android Accessibility Settings, and manually switch StudyGuard's service off for the payment. Re-enable it afterward. Android does not let a normal app silently disable its own accessibility service.

## Strict Mode limitation
Strict Mode is an in-app commitment aid. It locks blocker switches and hides the normal end-session action, but it cannot prevent uninstalling, force-stop, or disabling the Accessibility Service from Android Settings. Emergency Exit is always available in the app.

## Detection and privacy
- Detection is best-effort and based on visible accessibility text/signals; false positives and missed screens are possible when social apps change their UI.
- StudyGuard only attempts to act inside Instagram and YouTube. Payment Mode pauses blocking.
- Visible screen signals are inspected locally and are not uploaded.
- Reports currently show a local total count; detailed daily/weekly charts are not included.

## Build
Open the `StudyGuard` folder in Android Studio or use the repository's GitHub Actions workflow to build a debug APK.
