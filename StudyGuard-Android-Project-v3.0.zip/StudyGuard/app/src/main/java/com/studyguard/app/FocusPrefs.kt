package com.studyguard.app

import android.content.Context

object FocusPrefs {
    private const val FILE = "studyguard_settings"
    private const val END_TIME = "focus_end_time"
    private const val BLOCK_COUNT = "blocked_count"
    private const val INSTAGRAM_ENABLED = "instagram_blocker_enabled"
    private const val YOUTUBE_ENABLED = "youtube_blocker_enabled"
    private const val STRICT_MODE = "strict_mode_enabled"
    private const val PAYMENT_MODE = "payment_mode_enabled"

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun endTime(context: Context): Long = prefs(context).getLong(END_TIME, 0L)
    fun isFocusActive(context: Context): Boolean =
        endTime(context) > System.currentTimeMillis()

    fun start(context: Context, minutes: Int) {
        prefs(context).edit()
            .putLong(END_TIME, System.currentTimeMillis() + minutes * 60_000L)
            .apply()
    }

    fun stop(context: Context) {
        prefs(context).edit().putLong(END_TIME, 0L).apply()
    }

    fun isInstagramEnabled(context: Context): Boolean =
        prefs(context).getBoolean(INSTAGRAM_ENABLED, true)
    fun setInstagramEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(INSTAGRAM_ENABLED, enabled).apply()
    }

    fun isYouTubeEnabled(context: Context): Boolean =
        prefs(context).getBoolean(YOUTUBE_ENABLED, true)
    fun setYouTubeEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(YOUTUBE_ENABLED, enabled).apply()
    }

    fun isStrictMode(context: Context): Boolean =
        prefs(context).getBoolean(STRICT_MODE, false)
    fun setStrictMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(STRICT_MODE, enabled).apply()
    }

    fun isPaymentMode(context: Context): Boolean =
        prefs(context).getBoolean(PAYMENT_MODE, false)
    fun setPaymentMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(PAYMENT_MODE, enabled).apply()
    }

    fun blockedCount(context: Context): Int = prefs(context).getInt(BLOCK_COUNT, 0)
    fun addBlocked(context: Context) {
        val p = prefs(context)
        p.edit().putInt(BLOCK_COUNT, p.getInt(BLOCK_COUNT, 0) + 1).apply()
    }
}
