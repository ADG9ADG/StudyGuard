# StudyGuard 3.1

## Changes in 3.1
- Payment Mode no longer pauses Instagram Reels or YouTube Shorts blocking.
- Strict Mode supports a custom duration in hours and minutes (1 minute to 24 hours).
- Removed the in-app Emergency Exit control. Android Settings remains the recovery route to disable the Accessibility Service or uninstall the app.
- UPI compatibility is not guaranteed: some banking apps reject any enabled Accessibility Service.

## Build
Run `gradle assembleDebug` from this project directory. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Important
Blocking uses best-effort Accessibility Service screen-signal detection. Social app interface changes can affect detection. Build success does not replace real-device testing.
