package com.studyguard.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartDisplay
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

private enum class StudyTab(val label: String) {
    HOME("Home"), BLOCKERS("Blockers"), FOCUS("Focus"), INSIGHTS("Insights"), SETTINGS("Settings")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyGuardApp() }
    }
}

@Composable
private fun StudyGuardApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(StudyTab.HOME) }
    var endTime by remember { mutableLongStateOf(FocusPrefs.endTime(context)) }
    var blocked by remember { mutableIntStateOf(FocusPrefs.blockedCount(context)) }
    var instagramOn by remember { mutableStateOf(FocusPrefs.isInstagramEnabled(context)) }
    var youtubeOn by remember { mutableStateOf(FocusPrefs.isYouTubeEnabled(context)) }
    var strictMode by remember { mutableStateOf(FocusPrefs.isStrictMode(context)) }
    var paymentMode by remember { mutableStateOf(FocusPrefs.isPaymentMode(context)) }
    var selectedMinutes by remember { mutableIntStateOf(45) }
    var strictHoursText by remember { mutableStateOf((FocusPrefs.strictDuration(context) / 60).toString()) }
    var strictMinutesText by remember { mutableStateOf((FocusPrefs.strictDuration(context) % 60).toString()) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            endTime = FocusPrefs.endTime(context)
            blocked = FocusPrefs.blockedCount(context)
            if (strictMode && endTime > 0L && now >= endTime) {
                FocusPrefs.setStrictMode(context, false)
                FocusPrefs.stop(context)
                strictMode = false
                endTime = 0L
            } else if (endTime > 0L && now >= endTime) {
                FocusPrefs.stop(context)
                endTime = 0L
            }
            delay(1000)
        }
    }

    val active = endTime > now
    val remaining = if (active) endTime - now else 0L
    val mins = TimeUnit.MILLISECONDS.toMinutes(remaining)
    val secs = TimeUnit.MILLISECONDS.toSeconds(remaining) % 60

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF25282D), onPrimary = Color.White,
        secondary = Color(0xFF626A73), background = Color(0xFFF3F5F7),
        surface = Color.White, surfaceVariant = Color(0xFFE9EDF1)
    )) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    StudyTab.values().forEach { item ->
                        val icon = when (item) {
                            StudyTab.HOME -> Icons.Outlined.Home
                            StudyTab.BLOCKERS -> Icons.Outlined.Lock
                            StudyTab.FOCUS -> Icons.Outlined.Timer
                            StudyTab.INSIGHTS -> Icons.Outlined.Assessment
                            StudyTab.SETTINGS -> Icons.Outlined.Settings
                        }
                        NavigationBarItem(
                            selected = tab == item, onClick = { tab = item },
                            icon = { Icon(icon, contentDescription = item.label) },
                            label = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("STUDYGUARD", style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                        Text(tab.label, style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold)
                    }
                    if (strictMode) AssistChip(onClick = { tab = StudyTab.SETTINGS },
                        label = { Text("Strict ON") }, leadingIcon = { Icon(Icons.Outlined.Lock, null) })
                }

                if (paymentMode) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF2FF))) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Payment Mode is active", fontWeight = FontWeight.Bold)
                            Text("Reels and Shorts blocking remains active. Some UPI apps may still reject enabled Accessibility Services.")
                        }
                    }
                }

                when (tab) {
                    StudyTab.HOME -> HomePage(
                        active, mins, secs, blocked, instagramOn, youtubeOn, strictMode, paymentMode,
                        selectedMinutes, { selectedMinutes = it },
                        onStart = {
                            FocusPrefs.start(context, selectedMinutes)
                            endTime = FocusPrefs.endTime(context)
                        },
                        onFocus = { tab = StudyTab.FOCUS },
                        onBlockers = { tab = StudyTab.BLOCKERS },
                        onSettings = { tab = StudyTab.SETTINGS }
                    )
                    StudyTab.BLOCKERS -> BlockersPage(
                        instagramOn, youtubeOn, strictMode,
                        onInstagram = { instagramOn = it; FocusPrefs.setInstagramEnabled(context, it) },
                        onYouTube = { youtubeOn = it; FocusPrefs.setYouTubeEnabled(context, it) }
                    )
                    StudyTab.FOCUS -> FocusPage(
                        active, mins, secs, selectedMinutes, { selectedMinutes = it }, strictMode,
                        onStart = { FocusPrefs.start(context, selectedMinutes); endTime = FocusPrefs.endTime(context) },
                        onStop = { FocusPrefs.stop(context); endTime = 0L }
                    )
                    StudyTab.INSIGHTS -> InsightsPage(blocked, active, instagramOn, youtubeOn)
                    StudyTab.SETTINGS -> SettingsPage(
                        strictMode, paymentMode,
                        onStrictEnable = {
                            val duration = (strictHoursText.toIntOrNull() ?: 0) * 60 +
                                (strictMinutesText.toIntOrNull() ?: 0)
                            FocusPrefs.setStrictDuration(context, duration)
                            FocusPrefs.start(context, duration)
                            endTime = FocusPrefs.endTime(context)
                            FocusPrefs.setStrictMode(context, true)
                            strictMode = true
                        },
                        strictHoursText = strictHoursText,
                        strictMinutesText = strictMinutesText,
                        onStrictHours = { strictHoursText = it },
                        onStrictMinutes = { strictMinutesText = it },
                        onPayment = {
                            paymentMode = it
                            FocusPrefs.setPaymentMode(context, it)
                        },
                        onAccessibility = {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    )
                }
            }
        }

    }
}

@Composable
private fun HomePage(
    active: Boolean, mins: Long, secs: Long, blocked: Int,
    instagramOn: Boolean, youtubeOn: Boolean, strict: Boolean, payment: Boolean,
    selectedMinutes: Int, onMinutes: (Int) -> Unit, onStart: () -> Unit,
    onFocus: () -> Unit, onBlockers: () -> Unit, onSettings: () -> Unit
) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (active) "FOCUS IN PROGRESS" else "YOUR FOCUS SPACE",
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            Text(if (active) "%02d:%02d".format(mins, secs) else "Make room for deep work",
                style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(if (active) "Your session is running." else "Block distractions with or without a focus timer.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!active) {
                DurationChoices(selectedMinutes, onMinutes)
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                    Text("Start $selectedMinutes-minute focus")
                }
            } else OutlinedButton(onClick = onFocus, modifier = Modifier.fillMaxWidth()) { Text("View focus session") }
        }
    }

    Text("PROTECTION STATUS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusCard("Instagram", if (instagramOn) "Protected" else "Off", Modifier.weight(1f))
        StatusCard("YouTube", if (youtubeOn) "Protected" else "Off", Modifier.weight(1f))
    }
    StatusCard("Strict Mode", if (strict) "Locked until timer ends" else "Off", Modifier.fillMaxWidth())
    StatusCard("Payment Mode", if (payment) "Blocking stays active" else "Ready", Modifier.fillMaxWidth())
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("Blocked attempts", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary)
            Text("$blocked", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Counted locally on this device.")
        }
    }
    OutlinedButton(onClick = onBlockers, modifier = Modifier.fillMaxWidth()) { Text("Manage blockers") }
    TextButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text("Payment and safety settings") }
}

@Composable
private fun StatusCard(title: String, status: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
            Text(status, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun BlockersPage(
    instagramOn: Boolean, youtubeOn: Boolean, strict: Boolean,
    onInstagram: (Boolean) -> Unit, onYouTube: (Boolean) -> Unit
) {
    Text("Choose what to block. Each switch works independently of the focus timer.",
        color = MaterialTheme.colorScheme.onSurfaceVariant)
    BlockerControl("Instagram Reels", "Block the Reels viewing experience.", instagramOn, strict, onInstagram)
    BlockerControl("YouTube Shorts", "Block Shorts while keeping standard videos available.", youtubeOn, strict, onYouTube)
    InfoCard("Strict Mode", if (strict) "Switches are locked until the custom timer expires."
        else "Choose a custom duration in Settings, then enable Strict Mode.")
    InfoCard("Detection note", "Detection is best-effort and based on visible accessibility signals. Social apps can change their interfaces.")
}

@Composable
private fun BlockerControl(
    title: String, detail: String, enabled: Boolean, locked: Boolean, onChange: (Boolean) -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(detail, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (locked) Text("Locked by Strict Mode", style = MaterialTheme.typography.labelSmall)
            }
            Switch(checked = enabled, onCheckedChange = onChange, enabled = !locked)
        }
    }
}

@Composable
private fun FocusPage(
    active: Boolean, mins: Long, secs: Long, selectedMinutes: Int,
    onMinutes: (Int) -> Unit, strictMode: Boolean, onStart: () -> Unit, onStop: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(if (active) "SESSION IN PROGRESS" else "FOCUS TIMER",
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            Text(if (active) "%02d:%02d".format(mins, secs) else "Choose your duration",
                style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            if (active) {
                Text("The focus timer is separate from the app blockers.")
                if (strictMode) {
                    Text("Strict Mode is active. The timer cannot be ended in the app.",
                        color = MaterialTheme.colorScheme.secondary)
                } else {
                    OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth()) { Text("End session") }
                }
            } else {
                DurationChoices(selectedMinutes, onMinutes)
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Start focus session") }
            }
        }
    }
    InfoCard("Tip", "Choose a custom hours-and-minutes duration in Settings to start Strict Mode.")
}

@Composable
private fun DurationChoices(selected: Int, onSelected: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
        listOf(25, 45, 60, 90, 120).forEach { value ->
            FilterChip(selected = selected == value, onClick = { onSelected(value) },
                label = { Text("$value min") })
        }
    }
}

@Composable
private fun InsightsPage(blocked: Int, active: Boolean, instagram: Boolean, youtube: Boolean) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("BLOCKED ATTEMPTS", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary)
            Text("$blocked", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
            Text("Total recorded locally by StudyGuard.")
        }
    }
    StatusCard("Focus timer", if (active) "Running" else "Not running", Modifier.fillMaxWidth())
    StatusCard("Instagram blocker", if (instagram) "Enabled" else "Disabled", Modifier.fillMaxWidth())
    StatusCard("YouTube blocker", if (youtube) "Enabled" else "Disabled", Modifier.fillMaxWidth())
    InfoCard("Reports", "Detailed daily and weekly charts are not included yet. This screen shows the local blocked-attempt total and current status.")
}

@Composable
private fun SettingsPage(
    strict: Boolean, payment: Boolean, onStrictEnable: () -> Unit,
    strictHoursText: String, strictMinutesText: String,
    onStrictHours: (String) -> Unit, onStrictMinutes: (String) -> Unit,
    onPayment: (Boolean) -> Unit, onAccessibility: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("FOCUS SAFETY", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary)
            Text("Strict Mode", fontWeight = FontWeight.SemiBold)
            Text(if (strict) "Active — blocker switches are locked until the timer expires."
                else "Set your own duration before starting Strict Mode.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!strict) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = strictHoursText,
                        onValueChange = { onStrictHours(it.filter(Char::isDigit).take(2)) },
                        label = { Text("Hours") }, modifier = Modifier.weight(1f), singleLine = true
                    )
                    OutlinedTextField(
                        value = strictMinutesText,
                        onValueChange = { onStrictMinutes(it.filter(Char::isDigit).take(2)) },
                        label = { Text("Minutes") }, modifier = Modifier.weight(1f), singleLine = true
                    )
                }
                val hours = strictHoursText.toIntOrNull() ?: 0
                val minutes = strictMinutesText.toIntOrNull() ?: 0
                val totalMinutes = hours * 60 + minutes
                Text("Duration: ${totalMinutes / 60} hr ${totalMinutes % 60} min",
                    style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = onStrictEnable,
                    enabled = totalMinutes in 1..1440 && minutes < 60,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Start Strict Mode") }
            }
            HorizontalDivider()
            Text("Strict Mode is a commitment aid, not device administration. Android Settings can still stop or uninstall the app.", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("UPI & PAYMENT COMPATIBILITY", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Payment Mode", fontWeight = FontWeight.SemiBold)
                    Text("Does not pause Reels or Shorts blocking.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = payment, onCheckedChange = onPayment)
            }
            Text("Important: Payment Mode never pauses blocking. Some UPI or banking apps may reject any enabled Accessibility Service. If that happens, you may need to turn StudyGuard's Accessibility Service off in Android Settings before paying, then re-enable it afterwards. Reels and Shorts cannot be guaranteed to remain blocked while the service is disabled.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onAccessibility, modifier = Modifier.fillMaxWidth()) {
                Text("Open Android Accessibility Settings")
            }
        }
    }
    InfoCard("Privacy", "StudyGuard checks visible screen signals locally and does not upload screen text. It does not read UPI PINs or payment details.")
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(body, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
