# StudyGuard v3.2

## v3.2 changes
- Added a custom StudyGuard adaptive launcher icon (shield, graduation cap, and book).
- Payment Mode provides a direct route to Android Accessibility Settings and detects whether StudyGuard’s Accessibility Service is enabled.
- Android does not allow an app to disable its own Accessibility Service. The user must switch it off manually before a UPI payment if their bank app flags it, then switch it back on afterwards. Reels/Shorts blocking is paused while the service is off. This does not guarantee every UPI app will accept the device.
- Strict Mode now stores its deadline separately from the normal Focus timer, so the two timers run independently.
- Version updated to 3.2 (versionCode 7).

## Build
Run `gradle assembleDebug` from this directory with Android SDK platform 35 and Java 17 installed.
