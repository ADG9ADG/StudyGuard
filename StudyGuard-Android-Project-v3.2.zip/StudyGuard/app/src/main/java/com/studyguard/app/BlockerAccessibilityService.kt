package com.studyguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Best-effort, on-device detector for Instagram Reels and YouTube Shorts.
 * It never reads or acts on UPI/banking app screens. Payment Mode does not pause blocking.
 */
class BlockerAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString() ?: return
        val isInstagram = pkg == "com.instagram.android" && FocusPrefs.isInstagramEnabled(this)
        val isYouTube = pkg == "com.google.android.youtube" && FocusPrefs.isYouTubeEnabled(this)
        if (!isInstagram && !isYouTube) return

        val root = rootInActiveWindow ?: return
        val signals = ScreenSignals()
        collectSignals(root, signals, 0)

        val likelyReels = isInstagram && signals.isInstagramReelsScreen()
        val likelyShorts = isYouTube && signals.isYouTubeShortsScreen()

        if (likelyReels || likelyShorts) {
            val now = System.currentTimeMillis()
            if (now - lastBlockedAt > 1800L) {
                lastBlockedAt = now
                FocusPrefs.addBlocked(this)
                Toast.makeText(
                    this,
                    if (likelyReels) "Instagram Reels blocked" else "YouTube Shorts blocked",
                    Toast.LENGTH_SHORT
                ).show()
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
    }

    private fun collectSignals(node: AccessibilityNodeInfo?, signals: ScreenSignals, depth: Int) {
        if (node == null || depth > 22) return
        val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
        val description = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
        val combined = "$text $description".trim()
        if (combined.isNotBlank()) signals.allText.add(combined)

        val selected = node.isSelected || (node.parent?.isSelected == true)
        if (selected && combined.isNotBlank()) signals.selectedText.add(combined)

        for (i in 0 until node.childCount) collectSignals(node.getChild(i), signals, depth + 1)
    }

    private class ScreenSignals {
        val allText = mutableListOf<String>()
        val selectedText = mutableListOf<String>()

        private fun hasAny(values: List<String>, vararg words: String): Boolean =
            values.any { value -> words.any { word -> value.contains(word) } }

        fun isYouTubeShortsScreen(): Boolean =
            hasAny(allText, "shorts player", "shorts video", "create a short",
                "use this sound", "remix this short")

        fun isInstagramReelsScreen(): Boolean {
            val selectedReelsTab = hasAny(selectedText, "reels")
            val reelsViewerActions = hasAny(allText,
                "original audio", "use audio", "reels video")
            return selectedReelsTab || reelsViewerActions
        }
    }

    override fun onInterrupt() = Unit
}
