# StudyGuard 3.0

Local-first Android focus helper: blocks Instagram Reels and YouTube Shorts, with a focus timer,
7-day stats and an uninstall-resistant strict mode.

## What's new in 3.0
- **Strict mode with uninstall protection.** Turning it on activates a no-policy device admin
  (Android then refuses to uninstall the app) and makes the accessibility service bounce you Home
  from Settings/installer screens that mention StudyGuard and offer uninstall / force stop /
  deactivate / turn off. Turning strict mode off removes the device admin, so the app uninstalls
  normally again.
- **Safe release.** Strict mode is released only through a 3-minute in-app countdown
  (`FocusPrefs.UNLOCK_DELAY_MS`), so you can never get permanently locked in.
- **UPI-friendly.** "Pause blocker for payment" switches the accessibility service off in one tap
  (`disableSelf()`); Home then offers a one-tap "Turn blocker back on".
- Simpler UI: 3 tabs, progress-ring timer, setup checklist, dark mode, 7-day chart.

## Build
Open in Android Studio, or push to GitHub and run the included "Build StudyGuard APK" workflow.

## Known limits
- Detection of Reels/Shorts and of Settings screens is text-based and best-effort. Screen wording
  differs between phone brands, so tune `DANGER_WORDS` / `GUARDED_PACKAGES` in
  `BlockerAccessibilityService.kt` if a screen slips through.
- Strict mode is a strong speed bump, not a vault: safe mode or adb can still remove the app.
- Set up the accessibility permission (and "Allow restricted settings" on Android 13+) BEFORE
  turning strict mode on, because strict mode also guards those screens.

## Emergency removal (if you ever need it)
`adb shell dpm remove-active-admin com.studyguard.app/.StudyGuardAdminReceiver` then
`adb uninstall com.studyguard.app`. Or boot into safe mode, where third-party accessibility
services are off, deactivate the device admin in Settings and uninstall.


## StudyGuard 4.0 safety and payment workflow

- Strict Mode locks blocker controls only inside StudyGuard. It does not register Device Admin and does not intercept Android Settings, installer, or recovery screens.
- Payment Mode opens Android Accessibility Settings. Android requires the user to manually disable or re-enable StudyGuard's Accessibility Service; ordinary apps cannot silently toggle that permission.
- While Accessibility is disabled, Reels and Shorts detection is paused. Re-enable the service after payment to resume blocking. UPI compatibility is not guaranteed by this workflow.
- The accessibility service reads only Instagram and YouTube event windows for best-effort Reels/Shorts detection. It no longer inspects or guards Settings screens.
