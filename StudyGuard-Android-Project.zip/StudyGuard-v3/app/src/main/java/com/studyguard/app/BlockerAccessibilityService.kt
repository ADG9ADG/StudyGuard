package com.studyguard.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * On-device, best-effort detector for Reels and Shorts, plus the strict-mode guard.
 *
 * Privacy: the manifest config limits which apps send events here. Only Instagram, YouTube
 * and the system Settings / installer screens are ever read. UPI and banking apps are not.
 */
class BlockerAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: BlockerAccessibilityService? = null

        private const val INSTAGRAM = "com.instagram.android"
        private const val YOUTUBE = "com.google.android.youtube"

        /** Screens where someone could uninstall the app or switch protection off. */
        private val GUARDED_PACKAGES = setOf(
            "com.android.settings",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.google.android.permissioncontroller",
            "com.samsung.android.packageinstaller",
            "com.miui.packageinstaller",
            "com.miui.securitycenter",
            "com.coloros.safecenter",
            "com.iqoo.secure"
        )

        /** A guarded screen that mentions StudyGuard and one of these is bounced to Home. */
        private val DANGER_WORDS = listOf(
            "uninstall", "force stop", "deactivate", "device admin", "turn off",
            "stop", "disable", "clear data", "clear storage", "remove", "use studyguard"
        )
    }

    private var lastBlockedAt = 0L
    private var lastGuardAt = 0L

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (pkg in GUARDED_PACKAGES) {
            if (FocusPrefs.isStrictMode(this)) guardSettings()
            return
        }

        val isInstagram = pkg == INSTAGRAM && FocusPrefs.isInstagramEnabled(this)
        val isYouTube = pkg == YOUTUBE && FocusPrefs.isYouTubeEnabled(this)
        if (!isInstagram && !isYouTube) return

        val root = rootInActiveWindow ?: return
        val signals = ScreenSignals()
        collectSignals(root, signals, 0)

        val likelyReels = isInstagram && signals.isInstagramReelsScreen()
        val likelyShorts = isYouTube && signals.isYouTubeShortsScreen()

        if (likelyReels || likelyShorts) {
            val now = System.currentTimeMillis()
            if (now - lastBlockedAt > 1800L) {
                lastBlockedAt = now
                FocusPrefs.addBlocked(this)
                Toast.makeText(
                    this,
                    if (likelyReels) "Instagram Reels blocked" else "YouTube Shorts blocked",
                    Toast.LENGTH_SHORT
                ).show()
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
    }

    /** Strict mode: send the user Home if they open a screen that could remove StudyGuard. */
    private fun guardSettings() {
        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        collectText(root, texts, 0)
        val screen = texts.joinToString(" ")
        if (!screen.contains("studyguard")) return
        if (DANGER_WORDS.none { screen.contains(it) }) return

        val now = System.currentTimeMillis()
        if (now - lastGuardAt < 1500L) return
        lastGuardAt = now

        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(
            this,
            "Strict mode is on. Release it inside StudyGuard first.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 22) return
        node.text?.toString()?.trim()?.lowercase()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.trim()?.lowercase()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) collectText(node.getChild(i), out, depth + 1)
    }

    private fun collectSignals(node: AccessibilityNodeInfo?, signals: ScreenSignals, depth: Int) {
        if (node == null || depth > 22) return

        val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
        val description = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
        val combined = "$text $description".trim()
        if (combined.isNotBlank()) signals.allText.add(combined)

        // YouTube and Instagram often expose the currently selected bottom tab
        // through AccessibilityNodeInfo.isSelected (sometimes on its parent).
        val selected = node.isSelected || (node.parent?.isSelected == true)
        if (selected && combined.isNotBlank()) signals.selectedText.add(combined)

        for (i in 0 until node.childCount) {
            collectSignals(node.getChild(i), signals, depth + 1)
        }
    }

    private class ScreenSignals {
        val allText = mutableListOf<String>()
        val selectedText = mutableListOf<String>()

        private fun hasAny(values: List<String>, vararg words: String): Boolean =
            values.any { value -> words.any { word -> value.contains(word) } }

        fun isYouTubeShortsScreen(): Boolean {
            // Do not use the selected bottom-navigation tab or generic "Remix"
            // action: both can also appear while a regular YouTube video is open.
            // Only use phrases associated with the Shorts viewing/creation UI.
            return hasAny(
                allText,
                "shorts player",
                "shorts video",
                "create a short",
                "use this sound",
                "remix this short"
            )
        }

        fun isInstagramReelsScreen(): Boolean {
            val selectedReelsTab = hasAny(selectedText, "reels")
            val reelsViewerActions = hasAny(
                allText,
                "original audio", "use audio", "remix", "reels video"
            )
            return selectedReelsTab || reelsViewerActions
        }
    }

    override fun onInterrupt() = Unit
}
