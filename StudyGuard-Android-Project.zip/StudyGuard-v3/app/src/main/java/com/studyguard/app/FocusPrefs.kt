package com.studyguard.app

import android.content.Context
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object FocusPrefs {
    /** How long you must wait before strict mode can be released. */
    const val UNLOCK_DELAY_MS = 3 * 60_000L

    /** After the wait is over, the unlock stays available for this long, then expires. */
    const val UNLOCK_WINDOW_MS = 10 * 60_000L

    private const val FILE = "studyguard_settings"
    private const val END_TIME = "focus_end_time"
    private const val DURATION = "focus_duration_ms"
    private const val BLOCK_COUNT = "blocked_count"
    private const val INSTAGRAM_ENABLED = "instagram_blocker_enabled"
    private const val YOUTUBE_ENABLED = "youtube_blocker_enabled"
    private const val STRICT_MODE = "strict_mode_enabled"
    private const val UNLOCK_REQUESTED_AT = "unlock_requested_at"
    private val DAY_FORMAT: DateTimeFormatter = DateTimeFormatter.BASIC_ISO_DATE

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- Focus timer -------------------------------------------------------
    fun endTime(context: Context): Long = prefs(context).getLong(END_TIME, 0L)
    fun totalMs(context: Context): Long = prefs(context).getLong(DURATION, 0L)
    fun isFocusActive(context: Context): Boolean = System.currentTimeMillis() < endTime(context)

    fun start(context: Context, minutes: Int) {
        val ms = minutes * 60_000L
        prefs(context).edit()
            .putLong(END_TIME, System.currentTimeMillis() + ms)
            .putLong(DURATION, ms)
            .apply()
    }

    fun stop(context: Context) {
        prefs(context).edit().putLong(END_TIME, 0L).apply()
    }

    // ---- Blockers ----------------------------------------------------------
    fun isInstagramEnabled(context: Context): Boolean =
        prefs(context).getBoolean(INSTAGRAM_ENABLED, true)

    fun setInstagramEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(INSTAGRAM_ENABLED, enabled).apply()
    }

    fun isYouTubeEnabled(context: Context): Boolean =
        prefs(context).getBoolean(YOUTUBE_ENABLED, true)

    fun setYouTubeEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(YOUTUBE_ENABLED, enabled).apply()
    }

    // ---- Strict mode -------------------------------------------------------
    fun isStrictMode(context: Context): Boolean = prefs(context).getBoolean(STRICT_MODE, false)

    fun setStrictMode(context: Context, enabled: Boolean) {
        val editor = prefs(context).edit().putBoolean(STRICT_MODE, enabled)
        if (!enabled) editor.putLong(UNLOCK_REQUESTED_AT, 0L)
        editor.apply()
    }

    fun unlockRequestedAt(context: Context): Long = prefs(context).getLong(UNLOCK_REQUESTED_AT, 0L)

    fun requestUnlock(context: Context) {
        prefs(context).edit().putLong(UNLOCK_REQUESTED_AT, System.currentTimeMillis()).apply()
    }

    fun cancelUnlock(context: Context) {
        prefs(context).edit().putLong(UNLOCK_REQUESTED_AT, 0L).apply()
    }

    // ---- Stats -------------------------------------------------------------
    fun blockedCount(context: Context): Int = prefs(context).getInt(BLOCK_COUNT, 0)

    private fun dayKey(date: LocalDate) = "blocked_day_" + date.format(DAY_FORMAT)

    fun addBlocked(context: Context) {
        val p = prefs(context)
        val key = dayKey(LocalDate.now())
        p.edit()
            .putInt(BLOCK_COUNT, p.getInt(BLOCK_COUNT, 0) + 1)
            .putInt(key, p.getInt(key, 0) + 1)
            .apply()
    }

    fun blockedOn(context: Context, date: LocalDate): Int = prefs(context).getInt(dayKey(date), 0)

    fun blockedToday(context: Context): Int = blockedOn(context, LocalDate.now())

    /** Oldest day first, today last. */
    fun blockedLastDays(context: Context, days: Int = 7): List<Pair<LocalDate, Int>> =
        (days - 1 downTo 0).map { back ->
            val date = LocalDate.now().minusDays(back.toLong())
            date to blockedOn(context, date)
        }
}
