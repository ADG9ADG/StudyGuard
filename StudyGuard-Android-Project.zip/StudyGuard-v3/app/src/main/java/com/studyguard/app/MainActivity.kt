package com.studyguard.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.util.Locale

// ---------------------------------------------------------------------------
// Theme: deep "answer-sheet" green, amber reserved for anything that needs attention.
// ---------------------------------------------------------------------------

private val LightColors = lightColorScheme(
    primary = Color(0xFF1E5B49),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5E8DE),
    onPrimaryContainer = Color(0xFF0F3A2E),
    secondary = Color(0xFF5A6B63),
    tertiary = Color(0xFF9A6200),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFBE7C2),
    onTertiaryContainer = Color(0xFF4A2F00),
    background = Color(0xFFF2F5F1),
    onBackground = Color(0xFF15231E),
    surface = Color.White,
    onSurface = Color(0xFF15231E),
    surfaceVariant = Color(0xFFE3EAE4),
    onSurfaceVariant = Color(0xFF4B5B54),
    outlineVariant = Color(0xFFCBD6CF),
    error = Color(0xFFB3261E)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7FCFAF),
    onPrimary = Color(0xFF06281D),
    primaryContainer = Color(0xFF1F4A3B),
    onPrimaryContainer = Color(0xFFC5EBDA),
    secondary = Color(0xFFA6B8AF),
    tertiary = Color(0xFFE8B04A),
    onTertiary = Color(0xFF3B2500),
    tertiaryContainer = Color(0xFF4A3300),
    onTertiaryContainer = Color(0xFFFBE7C2),
    background = Color(0xFF0E1512),
    onBackground = Color(0xFFE3EBE6),
    surface = Color(0xFF16201C),
    onSurface = Color(0xFFE3EBE6),
    surfaceVariant = Color(0xFF233029),
    onSurfaceVariant = Color(0xFFA9B8B0),
    outlineVariant = Color(0xFF34443B),
    error = Color(0xFFF2B8B5)
)

private val AppTypography = Typography().let { t ->
    t.copy(
        displayMedium = t.displayMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
        headlineMedium = t.headlineMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
        headlineSmall = t.headlineSmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
        titleLarge = t.titleLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold)
    )
}

private enum class Screen(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Outlined.Home),
    STATS("Stats", Icons.Outlined.BarChart),
    SETTINGS("Settings", Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { StudyGuardApp() }
    }
}

// ---------------------------------------------------------------------------
// App root: owns all state and every action, so screens stay simple.
// ---------------------------------------------------------------------------

@Composable
private fun StudyGuardApp() {
    val context = LocalContext.current

    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    var selectedMinutes by rememberSaveable { mutableIntStateOf(45) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var endTime by remember { mutableLongStateOf(FocusPrefs.endTime(context)) }
    var totalMs by remember { mutableLongStateOf(FocusPrefs.totalMs(context)) }
    var blocked by remember { mutableIntStateOf(FocusPrefs.blockedCount(context)) }
    var blockedToday by remember { mutableIntStateOf(FocusPrefs.blockedToday(context)) }
    var week by remember { mutableStateOf(FocusPrefs.blockedLastDays(context)) }
    var instagramOn by remember { mutableStateOf(FocusPrefs.isInstagramEnabled(context)) }
    var youtubeOn by remember { mutableStateOf(FocusPrefs.isYouTubeEnabled(context)) }
    var strictMode by remember { mutableStateOf(FocusPrefs.isStrictMode(context)) }
    var a11yOn by remember { mutableStateOf(Protection.isAccessibilityEnabled(context)) }
    var adminOn by remember { mutableStateOf(Protection.isAdminActive(context)) }
    var unlockAt by remember { mutableLongStateOf(FocusPrefs.unlockRequestedAt(context)) }
    var showStrictDialog by remember { mutableStateOf(false) }

    // One ticker keeps timer, stats and permission status fresh (also after returning from Settings).
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            endTime = FocusPrefs.endTime(context)
            totalMs = FocusPrefs.totalMs(context)
            blocked = FocusPrefs.blockedCount(context)
            blockedToday = FocusPrefs.blockedToday(context)
            week = FocusPrefs.blockedLastDays(context)
            a11yOn = Protection.isAccessibilityEnabled(context)
            adminOn = Protection.isAdminActive(context)
            if (endTime > 0L && now >= endTime) {
                FocusPrefs.stop(context)
                endTime = 0L
            }
            val requested = FocusPrefs.unlockRequestedAt(context)
            if (requested > 0L && now > requested + FocusPrefs.UNLOCK_DELAY_MS + FocusPrefs.UNLOCK_WINDOW_MS) {
                FocusPrefs.cancelUnlock(context)
            }
            unlockAt = FocusPrefs.unlockRequestedAt(context)
            delay(1000)
        }
    }

    val active = endTime > now
    val remaining = if (active) endTime - now else 0L
    val unlockReady = unlockAt > 0L && now - unlockAt >= FocusPrefs.UNLOCK_DELAY_MS
    val unlockLeft =
        if (unlockAt > 0L && !unlockReady) unlockAt + FocusPrefs.UNLOCK_DELAY_MS - now else 0L
    val canEnd = !strictMode || unlockReady

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

    val openAccessibility: () -> Unit = { Protection.openAccessibilitySettings(context) }
    val requestAdmin: () -> Unit = { }

    val startSession: () -> Unit = {
        FocusPrefs.start(context, selectedMinutes)
        endTime = FocusPrefs.endTime(context)
        totalMs = FocusPrefs.totalMs(context)
        if (!a11yOn) toast("Turn on the blocking service so your blockers can work.")
    }
    val endSession: () -> Unit = {
        FocusPrefs.stop(context)
        FocusPrefs.cancelUnlock(context)
        endTime = 0L
        unlockAt = 0L
    }
    val pauseForPayment: () -> Unit = {
        // Android does not allow an ordinary app to toggle its own Accessibility permission.
        // Open the system page; the user must switch StudyGuard off manually for UPI.
        FocusPrefs.cancelUnlock(context)
        unlockAt = 0L
        toast("Turn StudyGuard off on the Accessibility screen, then return to your UPI app.")
        openAccessibility()
    }
    val confirmStrictOn: () -> Unit = {
        FocusPrefs.setStrictMode(context, true)
        strictMode = true
        showStrictDialog = false
    }
    val turnOffStrict: () -> Unit = {
        FocusPrefs.setStrictMode(context, false)
        strictMode = false
        adminOn = false
        unlockAt = 0L
        toast("Strict mode is off. StudyGuard can be uninstalled normally.")
    }
    val startUnlock: () -> Unit = {
        FocusPrefs.requestUnlock(context)
        unlockAt = FocusPrefs.unlockRequestedAt(context)
    }
    val cancelUnlock: () -> Unit = {
        FocusPrefs.cancelUnlock(context)
        unlockAt = 0L
    }

    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = AppTypography
    ) {
        if (showStrictDialog) {
            AlertDialog(
                onDismissRequest = { showStrictDialog = false },
                title = { Text("Turn on strict mode?") },
                text = {
                    Text(
                        "While strict mode is on, blocker switches are locked in StudyGuard. Android Settings can still be used for recovery. To release it you start a ${FocusPrefs.UNLOCK_DELAY_MS / 60_000}-minute " +
                            "countdown first.\n\nSet up the blocking service before you continue."
                    )
                },
                confirmButton = { TextButton(onClick = confirmStrictOn) { Text("Turn on strict mode") } },
                dismissButton = { TextButton(onClick = { showStrictDialog = false }) { Text("Not now") } }
            )
        }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    Screen.entries.forEachIndexed { index, item ->
                        NavigationBarItem(
                            selected = tabIndex == index,
                            onClick = { tabIndex = index },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Header(strictMode)

                when (Screen.entries[tabIndex]) {
                    Screen.HOME -> HomeScreen(
                        active = active,
                        remainingMs = remaining,
                        totalMs = totalMs,
                        selectedMinutes = selectedMinutes,
                        onMinutes = { selectedMinutes = it },
                        strictMode = strictMode,
                        canEnd = canEnd,
                        onStart = startSession,
                        onEnd = endSession,
                        a11yOn = a11yOn,
                        adminOn = adminOn,
                        onOpenAccessibility = openAccessibility,
                        onRequestAdmin = requestAdmin,
                        instagramOn = instagramOn,
                        onInstagram = { instagramOn = it; FocusPrefs.setInstagramEnabled(context, it) },
                        youtubeOn = youtubeOn,
                        onYouTube = { youtubeOn = it; FocusPrefs.setYouTubeEnabled(context, it) },
                        blockedToday = blockedToday,
                        unlockReady = unlockReady,
                        onPause = pauseForPayment,
                        onGoToSettings = { tabIndex = Screen.SETTINGS.ordinal }
                    )

                    Screen.STATS -> StatsScreen(blocked, blockedToday, week)

                    Screen.SETTINGS -> SettingsScreen(
                        strictMode = strictMode,
                        onStrictToggle = { wantOn ->
                            if (wantOn) showStrictDialog = true
                        },
                        unlockAt = unlockAt,
                        unlockReady = unlockReady,
                        unlockLeftMs = unlockLeft,
                        onStartUnlock = startUnlock,
                        onCancelUnlock = cancelUnlock,
                        onTurnOffStrict = turnOffStrict,
                        onPause = pauseForPayment,
                        a11yOn = a11yOn,
                        adminOn = adminOn,
                        onOpenAccessibility = openAccessibility,
                        onRequestAdmin = requestAdmin
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Shared building blocks
// ---------------------------------------------------------------------------

@Composable
private fun Header(strictMode: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            "StudyGuard",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.weight(1f)
        )
        if (strictMode) {
            AssistChip(
                onClick = {},
                label = { Text("Strict mode on") },
                leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null, Modifier.size(18.dp)) }
            )
        }
    }
}

@Composable
private fun Panel(
    modifier: Modifier = Modifier,
    corner: Dp = 20.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(corner),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
private fun Hint(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun ToggleRow(
    title: String,
    detail: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    icon: ImageVector,
    enabled: Boolean = true
) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(
                detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun StatusRow(
    title: String,
    detail: String,
    ok: Boolean,
    actionLabel: String?,
    onAction: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(
            if (ok) Icons.Outlined.CheckCircle else Icons.Outlined.ErrorOutline,
            contentDescription = null,
            tint = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
        )
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(
                detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (!ok && actionLabel != null) {
            FilledTonalButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

private fun clock(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------

@Composable
private fun HomeScreen(
    active: Boolean,
    remainingMs: Long,
    totalMs: Long,
    selectedMinutes: Int,
    onMinutes: (Int) -> Unit,
    strictMode: Boolean,
    canEnd: Boolean,
    onStart: () -> Unit,
    onEnd: () -> Unit,
    a11yOn: Boolean,
    adminOn: Boolean,
    onOpenAccessibility: () -> Unit,
    onRequestAdmin: () -> Unit,
    instagramOn: Boolean,
    onInstagram: (Boolean) -> Unit,
    youtubeOn: Boolean,
    onYouTube: (Boolean) -> Unit,
    blockedToday: Int,
    unlockReady: Boolean,
    onPause: () -> Unit,
    onGoToSettings: () -> Unit
) {
    // Session hero: the ring is the one memorable element on this screen.
    Panel(corner = 32.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            val progress =
                if (active && totalMs > 0L) remainingMs.toFloat() / totalMs.toFloat()
                else selectedMinutes / 90f
            FocusRing(
                progress = progress,
                title = if (active) clock(remainingMs) else "$selectedMinutes",
                caption = if (active) "left in this session" else "minutes"
            )
        }

        if (active) {
            if (canEnd) {
                OutlinedButton(onClick = onEnd, modifier = Modifier.fillMaxWidth()) {
                    Text("End session")
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                    Hint("Strict mode is on, so this session can't be ended early. To release it, start the unlock countdown in Settings.")
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(25, 45, 60, 90).forEach { minutes ->
                    FilterChip(
                        modifier = Modifier.weight(1f),
                        selected = selectedMinutes == minutes,
                        onClick = { onMinutes(minutes) },
                        label = { Text("$minutes", Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
                    )
                }
            }
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                Text("Start $selectedMinutes-minute session")
            }
        }
    }

    // Setup checklist only appears when something needs fixing.
    val needsAdmin = false
    if (!a11yOn) {
        Panel(corner = 24.dp) {
            Text("Finish setup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (!a11yOn) {
                StatusRow(
                    title = "Blocking service is off",
                    detail = "Reels and Shorts won't be blocked until you turn it on.",
                    ok = false,
                    actionLabel = "Turn on",
                    onAction = onOpenAccessibility
                )
            }
        }
    }

    Panel {
        Text("Blockers", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        ToggleRow(
            title = "Instagram Reels",
            detail = if (instagramOn) "Blocked. Posts and messages stay open." else "Off. Reels work normally.",
            checked = instagramOn,
            onChange = onInstagram,
            icon = Icons.Outlined.VideoLibrary,
            enabled = !strictMode
        )
        ToggleRow(
            title = "YouTube Shorts",
            detail = if (youtubeOn) "Blocked. Regular videos stay open." else "Off. Shorts work normally.",
            checked = youtubeOn,
            onChange = onYouTube,
            icon = Icons.Outlined.SmartDisplay,
            enabled = !strictMode
        )
        if (strictMode) Hint("Locked while strict mode is on.")
        Hint(
            if (blockedToday == 0) "Nothing blocked today yet."
            else "$blockedToday blocked today."
        )
    }

    PaymentCard(
        strictMode = strictMode,
        unlockReady = unlockReady,
        a11yOn = a11yOn,
        onPause = onPause,
        onTurnOn = onOpenAccessibility,
        onGoToSettings = onGoToSettings
    )
}

@Composable
private fun FocusRing(progress: Float, title: String, caption: String) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        label = "focus-ring"
    )
    val track = MaterialTheme.colorScheme.surfaceVariant
    val arc = MaterialTheme.colorScheme.primary
    val strokePx = with(LocalDensity.current) { 12.dp.toPx() }

    Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val inset = strokePx / 2
            val arcSize = Size(size.width - strokePx, size.height - strokePx)
            drawArc(
                color = track,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = strokePx)
            )
            drawArc(
                color = arc,
                startAngle = -90f,
                sweepAngle = 360f * animated,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.displayMedium)
            Text(
                caption,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PaymentCard(
    strictMode: Boolean,
    unlockReady: Boolean,
    a11yOn: Boolean,
    onPause: () -> Unit,
    onTurnOn: () -> Unit,
    onGoToSettings: () -> Unit
) {
    Panel {
        Text("Paying with UPI?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        when {
            !a11yOn -> {
                Hint("StudyGuard Accessibility is off. Re-enable it here in Android Settings after your payment; Reels and Shorts blocking is paused meanwhile.")
                FilledTonalButton(onClick = onTurnOn, modifier = Modifier.fillMaxWidth()) {
                    Text("Open Accessibility Settings")
                }
            }
            strictMode && !unlockReady -> {
                Hint("Strict mode is on. Start the unlock countdown in Settings, then you can pause the blocker.")
                OutlinedButton(onClick = onGoToSettings, modifier = Modifier.fillMaxWidth()) {
                    Text("Open Settings")
                }
            }
            else -> {
                Hint("Some UPI and banking apps flag enabled Accessibility Services. Android requires you to switch StudyGuard off manually in system settings. Blocking pauses until you turn it back on.")
                FilledTonalButton(onClick = onPause, modifier = Modifier.fillMaxWidth()) {
                    Text("Open Accessibility Settings")
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------

@Composable
private fun StatsScreen(total: Int, today: Int, week: List<Pair<LocalDate, Int>>) {
    Panel(corner = 28.dp) {
        Text("Screens blocked", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text("$total", style = MaterialTheme.typography.displayMedium)
        Hint(if (total == 0) "Nothing yet. When StudyGuard steps in, it shows up here." else "$today of them today.")
    }
    Panel {
        Text("Last 7 days", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        WeekBars(week)
    }
    Hint("History starts from the day you install this version.")
}

@Composable
private fun WeekBars(days: List<Pair<LocalDate, Int>>) {
    val max = (days.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    Row(
        Modifier.fillMaxWidth().height(150.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        days.forEachIndexed { index, (date, count) ->
            val isToday = index == days.lastIndex
            val barColor =
                if (isToday) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom
            ) {
                Text("$count", style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height((count.toFloat() / max * 80f).coerceAtLeast(4f).dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(barColor)
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    date.dayOfWeek.getDisplayName(java.time.format.TextStyle.NARROW, Locale.getDefault()),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

@Composable
private fun SettingsScreen(
    strictMode: Boolean,
    onStrictToggle: (Boolean) -> Unit,
    unlockAt: Long,
    unlockReady: Boolean,
    unlockLeftMs: Long,
    onStartUnlock: () -> Unit,
    onCancelUnlock: () -> Unit,
    onTurnOffStrict: () -> Unit,
    onPause: () -> Unit,
    a11yOn: Boolean,
    adminOn: Boolean,
    onOpenAccessibility: () -> Unit,
    onRequestAdmin: () -> Unit
) {
    val delayMinutes = FocusPrefs.UNLOCK_DELAY_MS / 60_000

    Panel {
        ToggleRow(
            title = "Strict mode",
            detail = "Locks blocker switches inside StudyGuard. Android Settings remains available for recovery.",
            checked = strictMode,
            onChange = onStrictToggle,
            icon = Icons.Outlined.Lock,
            enabled = !strictMode
        )

        if (strictMode) {
            HorizontalDivider()
            when {
                unlockReady -> {
                    Text("Unlocked", fontWeight = FontWeight.SemiBold)
                    Hint("You can release strict mode now. The unlock expires after ${FocusPrefs.UNLOCK_WINDOW_MS / 60_000} minutes.")
                    Button(onClick = onTurnOffStrict, modifier = Modifier.fillMaxWidth()) {
                        Text("Turn off strict mode")
                    }
                    FilledTonalButton(onClick = onPause, modifier = Modifier.fillMaxWidth()) {
                        Text("Open Accessibility Settings")
                    }
                    TextButton(onClick = onCancelUnlock, modifier = Modifier.fillMaxWidth()) {
                        Text("Keep strict mode on")
                    }
                }
                unlockAt > 0L -> {
                    Text("Unlock ready in ${clock(unlockLeftMs)}", fontWeight = FontWeight.SemiBold)
                    LinearProgressIndicator(
                        progress = {
                            (1f - unlockLeftMs.toFloat() / FocusPrefs.UNLOCK_DELAY_MS.toFloat()).coerceIn(0f, 1f)
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Hint("Use the wait to decide if you really need this.")
                    TextButton(onClick = onCancelUnlock, modifier = Modifier.fillMaxWidth()) {
                        Text("Cancel countdown")
                    }
                }
                else -> {
                    Hint("To release strict mode or pause the blocker, start a $delayMinutes-minute countdown first.")
                    OutlinedButton(onClick = onStartUnlock, modifier = Modifier.fillMaxWidth()) {
                        Text("Start $delayMinutes-minute unlock countdown")
                    }
                }
            }
        }
    }

    Panel {
        Text("Permissions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        StatusRow(
            title = "Blocking service",
            detail = if (a11yOn) "On" else "Off. Needed to detect Reels and Shorts.",
            ok = a11yOn,
            actionLabel = "Turn on",
            onAction = onOpenAccessibility
        )
        Hint("If Android restricts the Accessibility switch, open StudyGuard App info and use Allow restricted settings if that option is available on your device.")
    }

    Panel {
        Text("How it works", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Hint("StudyGuard reads on-screen text locally to spot Reels and Shorts. Nothing is uploaded, and it only looks at Instagram, YouTube and system Settings screens, never payment apps.")
        Hint("Detection is best-effort and may need updates when Instagram or YouTube change their screens.")
        Hint("Strict Mode only locks controls inside StudyGuard. Android Settings remains available for recovery and uninstalling the app is never prevented.")
    }
}
