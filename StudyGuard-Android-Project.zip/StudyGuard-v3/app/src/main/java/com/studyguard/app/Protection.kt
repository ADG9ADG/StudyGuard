package com.studyguard.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Helpers for the two things strict mode relies on: the accessibility service and device admin. */
object Protection {
    private fun serviceComponent(context: Context) =
        ComponentName(context, BlockerAccessibilityService::class.java)

    private fun adminComponent(context: Context) =
        ComponentName(context, StudyGuardAdminReceiver::class.java)

    private fun dpm(context: Context) =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    fun isAccessibilityEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val target = serviceComponent(context)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == target }
    }

    fun openAccessibilitySettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    fun isAdminActive(context: Context): Boolean = dpm(context).isAdminActive(adminComponent(context))

    fun adminRequestIntent(context: Context): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent(context))
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "While strict mode is on, Android will not let StudyGuard be uninstalled. " +
                    "Turning strict mode off inside StudyGuard removes this permission automatically."
            )
        }

    /** Gives up device admin so the app can be uninstalled normally again. */
    fun releaseAdmin(context: Context) {
        val manager = dpm(context)
        val admin = adminComponent(context)
        if (manager.isAdminActive(admin)) manager.removeActiveAdmin(admin)
    }
}
