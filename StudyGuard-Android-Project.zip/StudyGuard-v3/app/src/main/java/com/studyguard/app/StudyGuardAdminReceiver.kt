package com.studyguard.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/**
 * Declares no policies. Its only job is to make Android refuse to uninstall the app
 * while it is an active device admin. StudyGuard removes it again when strict mode is released.
 */
class StudyGuardAdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence? =
        if (FocusPrefs.isStrictMode(context)) {
            "Strict mode is on. Release it inside StudyGuard first; that removes this permission cleanly."
        } else {
            null
        }
}
