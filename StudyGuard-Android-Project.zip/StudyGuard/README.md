# StudyGuard 2.0

A local-first Android focus helper with separate Instagram Reels and YouTube Shorts controls.

## Screens
- Home: session overview and blocker shortcuts
- Instagram: independent Reels blocker switch
- YouTube: independent Shorts blocker switch
- Focus: 25/45/60/90-minute focus timer
- Reports: locally stored blocked-screen total
- Settings: strict-mode option and accessibility setup

## Build
Open this project in Android Studio or use the included GitHub Actions workflow. The workflow builds a debug APK.

## Important limitations
- Blocking is best-effort text-based accessibility detection. Social apps change their interfaces, so false positives and missed screens are possible.
- Blocking only runs during an active focus session and only for the app-specific switches that are enabled.
- Strict mode hides the in-app end-session button. It is not tamper-proof and cannot prevent Android settings, force-stop, or uninstall.
- The Reports screen currently displays the locally stored total, not a detailed daily/weekly history.
- The app inspects visible accessibility text locally and does not upload it.
