package com.studyguard.app

import android.content.Context

object FocusPrefs {
    private const val FILE = "studyguard_settings"
    private const val END_TIME = "focus_end_time"
    private const val BLOCK_COUNT = "blocked_count"

    fun endTime(context: Context): Long =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getLong(END_TIME, 0L)

    fun isFocusActive(context: Context): Boolean =
        System.currentTimeMillis() < endTime(context)

    fun start(context: Context, minutes: Int) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putLong(END_TIME, System.currentTimeMillis() + minutes * 60_000L)
            .apply()
    }

    fun stop(context: Context) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putLong(END_TIME, 0L)
            .apply()
    }

    fun blockedCount(context: Context): Int =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt(BLOCK_COUNT, 0)

    fun addBlocked(context: Context) {
        val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        prefs.edit().putInt(BLOCK_COUNT, prefs.getInt(BLOCK_COUNT, 0) + 1).apply()
    }
}
