package com.studyguard.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyGuardScreen() }
    }
}

@Composable
private fun StudyGuardScreen() {
    val context = LocalContext.current
    var endTime by remember { mutableLongStateOf(FocusPrefs.endTime(context)) }
    var blocked by remember { mutableIntStateOf(FocusPrefs.blockedCount(context)) }
    var selectedMinutes by remember { mutableIntStateOf(45) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            endTime = FocusPrefs.endTime(context)
            blocked = FocusPrefs.blockedCount(context)
            if (endTime > 0L && now >= endTime) {
                FocusPrefs.stop(context)
                endTime = 0L
            }
            delay(1000)
        }
    }

    val active = endTime > now
    val remaining = if (active) endTime - now else 0L
    val mins = TimeUnit.MILLISECONDS.toMinutes(remaining)
    val secs = TimeUnit.MILLISECONDS.toSeconds(remaining) % 60

    MaterialTheme(colorScheme = lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF171717),
        background = androidx.compose.ui.graphics.Color(0xFFF7F7F7),
        surface = androidx.compose.ui.graphics.Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text("STUDYGUARD", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Text("Protect your focus.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Block the scroll. Keep the learning.", color = MaterialTheme.colorScheme.onSurfaceVariant)

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (active) "FOCUS SESSION ACTIVE" else "READY WHEN YOU ARE",
                            style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(12.dp))
                        Text(if (active) "%02d:%02d".format(mins, secs) else "— — : — —",
                            style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(if (active) "Instagram Reels and YouTube Shorts blocking is on"
                             else "Choose a session to turn on blocking",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(18.dp))
                        if (active) {
                            Button(onClick = {
                                FocusPrefs.stop(context)
                                endTime = 0L
                            }, modifier = Modifier.fillMaxWidth()) { Text("End focus session") }
                        } else {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(25, 45, 60, 90, 120).forEach { value ->
                                    FilterChip(
                                        selected = selectedMinutes == value,
                                        onClick = { selectedMinutes = value },
                                        label = { Text("$value") }
                                    )
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = {
                                FocusPrefs.start(context, selectedMinutes)
                                endTime = FocusPrefs.endTime(context)
                            }, modifier = Modifier.fillMaxWidth()) {
                                Text("Start $selectedMinutes-minute focus")
                            }
                        }
                    }
                }

                Text("YOUR BLOCKER", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Instagram Reels")
                            Text("Targeted", fontWeight = FontWeight.SemiBold)
                        }
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("YouTube Shorts")
                            Text("Targeted", fontWeight = FontWeight.SemiBold)
                        }
                        HorizontalDivider()
                        Text("Normal Instagram posts, messages and regular YouTube videos are intended to remain available.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Text("TODAY", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("$blocked", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                        Text("likely distraction screens blocked on this device")
                    }
                }

                OutlinedButton(
                    onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Enable StudyGuard accessibility service") }

                Text(
                    "Setup: enable “StudyGuard content blocker” in Android Accessibility settings. Android requires this permission so the app can identify the active screen and press Back when a likely Reels or Shorts screen appears. Screen text is processed on-device and is not saved or uploaded.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Note: detection is best-effort. Instagram and YouTube can change their layouts, so some screens may not be detected or may occasionally be misidentified. Keep accessibility enabled for blocking to work.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
