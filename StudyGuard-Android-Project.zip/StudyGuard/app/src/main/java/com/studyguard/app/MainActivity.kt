package com.studyguard.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartDisplay
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

private enum class StudyTab(val label: String) {
    HOME("Home"), INSTAGRAM("Instagram"), YOUTUBE("YouTube"),
    FOCUS("Focus"), REPORTS("Reports"), SETTINGS("Settings")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyGuardApp() }
    }
}

@Composable
private fun StudyGuardApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(StudyTab.HOME) }
    var endTime by remember { mutableLongStateOf(FocusPrefs.endTime(context)) }
    var blocked by remember { mutableIntStateOf(FocusPrefs.blockedCount(context)) }
    var instagramOn by remember { mutableStateOf(FocusPrefs.isInstagramEnabled(context)) }
    var youtubeOn by remember { mutableStateOf(FocusPrefs.isYouTubeEnabled(context)) }
    var strictMode by remember { mutableStateOf(FocusPrefs.isStrictMode(context)) }
    var selectedMinutes by remember { mutableIntStateOf(45) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            endTime = FocusPrefs.endTime(context)
            blocked = FocusPrefs.blockedCount(context)
            if (endTime > 0L && now >= endTime) {
                FocusPrefs.stop(context)
                endTime = 0L
            }
            delay(1000)
        }
    }

    val active = endTime > now
    val remaining = if (active) endTime - now else 0L
    val mins = TimeUnit.MILLISECONDS.toMinutes(remaining)
    val secs = TimeUnit.MILLISECONDS.toSeconds(remaining) % 60

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF202124),
        onPrimary = Color.White,
        secondary = Color(0xFF5F6368),
        background = Color(0xFFF5F6F7),
        surface = Color.White,
        surfaceVariant = Color(0xFFEAEBED)
    )) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    StudyTab.values().forEach { item ->
                        val icon = when (item) {
                            StudyTab.HOME -> Icons.Outlined.Home
                            StudyTab.INSTAGRAM -> Icons.Outlined.VideoLibrary
                            StudyTab.YOUTUBE -> Icons.Outlined.SmartDisplay
                            StudyTab.FOCUS -> Icons.Outlined.Timer
                            StudyTab.REPORTS -> Icons.Outlined.Assessment
                            StudyTab.SETTINGS -> Icons.Outlined.Settings
                        }
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(icon, contentDescription = item.label) },
                            label = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("STUDYGUARD", style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                        Text(tab.label, style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold)
                    }
                    if (active) AssistChip(onClick = { tab = StudyTab.FOCUS },
                        label = { Text("Focus active") })
                }

                when (tab) {
                    StudyTab.HOME -> HomePage(
                        active, mins, secs, blocked, instagramOn, youtubeOn,
                        selectedMinutes, { selectedMinutes = it },
                        onStart = {
                            FocusPrefs.start(context, selectedMinutes)
                            endTime = FocusPrefs.endTime(context)
                        },
                        onEnd = {
                            if (!strictMode) {
                                FocusPrefs.stop(context)
                                endTime = 0L
                            }
                        },
                        onOpenInstagram = { tab = StudyTab.INSTAGRAM },
                        onOpenYouTube = { tab = StudyTab.YOUTUBE },
                        onOpenFocus = { tab = StudyTab.FOCUS }
                    )
                    StudyTab.INSTAGRAM -> BlockerPage(
                        title = "Instagram Reels",
                        subtitle = "Control Reels blocking without changing your YouTube settings.",
                        enabled = instagramOn,
                        onEnabledChange = {
                            instagramOn = it
                            FocusPrefs.setInstagramEnabled(context, it)
                        },
                        active = active,
                        appName = "Instagram"
                    )
                    StudyTab.YOUTUBE -> BlockerPage(
                        title = "YouTube Shorts",
                        subtitle = "Control Shorts blocking independently from Instagram.",
                        enabled = youtubeOn,
                        onEnabledChange = {
                            youtubeOn = it
                            FocusPrefs.setYouTubeEnabled(context, it)
                        },
                        active = active,
                        appName = "YouTube"
                    )
                    StudyTab.FOCUS -> FocusPage(
                        active, mins, secs, selectedMinutes, { selectedMinutes = it },
                        strictMode,
                        onStart = {
                            FocusPrefs.start(context, selectedMinutes)
                            endTime = FocusPrefs.endTime(context)
                        },
                        onEnd = {
                            if (!strictMode) {
                                FocusPrefs.stop(context)
                                endTime = 0L
                            }
                        }
                    )
                    StudyTab.REPORTS -> ReportsPage(blocked, active)
                    StudyTab.SETTINGS -> SettingsPage(
                        strictMode = strictMode,
                        onStrictChange = {
                            strictMode = it
                            FocusPrefs.setStrictMode(context, it)
                        },
                        onAccessibility = {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomePage(
    active: Boolean, mins: Long, secs: Long, blocked: Int,
    instagramOn: Boolean, youtubeOn: Boolean,
    selectedMinutes: Int, onMinutes: (Int) -> Unit,
    onStart: () -> Unit, onEnd: () -> Unit,
    onOpenInstagram: () -> Unit, onOpenYouTube: () -> Unit, onOpenFocus: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.Start) {
            Text(if (active) "YOUR FOCUS SESSION" else "READY WHEN YOU ARE",
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.height(8.dp))
            Text(if (active) "%02d:%02d".format(mins, secs) else "Protect your focus.",
                style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Blockers work independently. The focus timer is optional.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            if (active) {
                Button(onClick = onEnd, modifier = Modifier.fillMaxWidth()) {
                    Text("End focus session")
                }
            } else {
                DurationChoices(selectedMinutes, onMinutes)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                    Text("Start $selectedMinutes-minute focus")
                }
            }
        }
    }

    Text("YOUR BLOCKERS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    BlockerSummaryCard("Instagram Reels", instagramOn, "Independent control", onOpenInstagram)
    BlockerSummaryCard("YouTube Shorts", youtubeOn, "Independent control", onOpenYouTube)

    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Blocked screens", style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary)
                Text("$blocked", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = onOpenFocus) { Text("Focus details") }
        }
    }
    Text(
        "Enabled blockers work even when the focus timer is off. Keep the StudyGuard accessibility service enabled. " +
            "Detection is best-effort and may need adjustment if Instagram or YouTube changes its interface.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun BlockerSummaryCard(title: String, enabled: Boolean, detail: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(detail, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(if (enabled) "ON" else "OFF", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun BlockerPage(
    title: String, subtitle: String, enabled: Boolean, onEnabledChange: (Boolean) -> Unit,
    active: Boolean, appName: String
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(if (enabled) "BLOCKER ENABLED" else "BLOCKER DISABLED",
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Enable $appName blocker", fontWeight = FontWeight.SemiBold)
                    Text("This switch affects only $appName.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = enabled, onCheckedChange = onEnabledChange)
            }
        }
    }
    InfoCard(
        "When does it block?",
        if (enabled) "This blocker is ON and works independently of the focus timer."
        else "This blocker is OFF. The selected app will work normally."
    )
    InfoCard(
        "What stays available?",
        "The detector is designed to target Reels/Shorts only. Regular posts, messages and standard videos are intended to remain accessible. Detection is heuristic, not guaranteed."
    )
}

@Composable
private fun FocusPage(
    active: Boolean, mins: Long, secs: Long, selectedMinutes: Int,
    onMinutes: (Int) -> Unit, strictMode: Boolean, onStart: () -> Unit, onEnd: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(if (active) "SESSION IN PROGRESS" else "FOCUS TIMER",
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            Text(if (active) "%02d:%02d".format(mins, secs) else "Choose your duration",
                style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            if (active) {
                Text("Stay with your task until the timer finishes.")
                if (strictMode) {
                    Text("Strict mode is on: the in-app end button is disabled.",
                        color = MaterialTheme.colorScheme.secondary)
                } else {
                    OutlinedButton(onClick = onEnd, modifier = Modifier.fillMaxWidth()) {
                        Text("End session")
                    }
                }
            } else {
                DurationChoices(selectedMinutes, onMinutes)
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                    Text("Start focus session")
                }
            }
        }
    }
    InfoCard("How blocking works",
        "Instagram and YouTube have separate switches. Each enabled blocker works whether the focus timer is running or not. The focus timer is a separate study timer.")
}

@Composable
private fun DurationChoices(selected: Int, onSelected: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
        listOf(25, 45, 60, 90).forEach { value ->
            FilterChip(selected = selected == value, onClick = { onSelected(value) },
                label = { Text("$value min") })
        }
    }
}

@Composable
private fun ReportsPage(blocked: Int, active: Boolean) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("TOTAL BLOCKED SCREENS", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary)
            Text("$blocked", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
            Text("Count recorded by StudyGuard on this device.")
        }
    }
    InfoCard("Session status", if (active) "A focus session is currently active." else "No active focus session.")
    InfoCard("Report availability", "Detailed daily and weekly history is not included in this version yet. This screen currently shows the locally stored total.")
}

@Composable
private fun SettingsPage(
    strictMode: Boolean, onStrictChange: (Boolean) -> Unit, onAccessibility: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Strict mode", fontWeight = FontWeight.SemiBold)
                    Text("Hides the in-app end-session control while a session is running.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = strictMode, onCheckedChange = onStrictChange)
            }
            HorizontalDivider()
            Text("Accessibility permission", fontWeight = FontWeight.SemiBold)
            Text("Required for StudyGuard to detect likely Reels and Shorts screens.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onAccessibility, modifier = Modifier.fillMaxWidth()) {
                Text("Open Accessibility settings")
            }
        }
    }
    InfoCard("Privacy", "Screen text is inspected locally by the accessibility service. StudyGuard does not upload that text.")
    InfoCard("Limitations", "Android may allow the user to stop the service or app. Strict mode is a simple in-app guard, not tamper-proof protection.")
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(body, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
