# StudyGuard Native Android

Native Kotlin + Jetpack Compose project (application ID: `com.studyguard.app`).

## Open and build
1. Extract this ZIP.
2. Open the `StudyGuard-Native` folder in Android Studio.
3. Use JDK 17 and Android SDK Platform 35.
4. Use Gradle 8.9 (Android Gradle Plugin 8.7.3).
5. Allow Android Studio to sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

This package includes Gradle wrapper configuration but not the wrapper JAR. If Android Studio reports that the Gradle wrapper launcher is missing, select a local Gradle 8.9 installation in Android Studio, or run `gradle wrapper --gradle-version 8.9` from an installed Gradle 8.9 terminal.

## Current scope and limitations
- Focus timer and basic on-device session count.
- Independent Reels and Shorts toggles.
- Accessibility service uses visible UI text heuristics. App UI changes may affect detection.
- Payment Mode opens Android Accessibility settings; the user must manually disable/re-enable the service.
- No Device Admin, anti-uninstall, or system-settings lock.
- Not yet validated on physical devices. Test Instagram feed/Reels and YouTube Shorts/normal videos before relying on it.
