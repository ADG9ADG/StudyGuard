package com.studyguard.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Ink = Color(0xFF202936)
private val Muted = Color(0xFF778292)
private val Canvas = Color(0xFFF3F5F7)
private val Accent = Color(0xFF526579)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyGuardApp(
            onAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            onAppDetails = { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:$packageName"))) }
        ) }
    }
}

@Composable
private fun StudyGuardApp(onAccessibility: () -> Unit, onAppDetails: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("studyguard", 0) }
    var tab by remember { mutableStateOf(0) }
    var reels by remember { mutableStateOf(prefs.getBoolean("block_reels", true)) }
    var shorts by remember { mutableStateOf(prefs.getBoolean("block_shorts", true)) }
    var payment by remember { mutableStateOf(prefs.getBoolean("payment_mode", false)) }
    var duration by remember { mutableIntStateOf(prefs.getInt("duration_min", 25)) }
    var runningUntil by remember { mutableLongStateOf(prefs.getLong("timer_until", 0L)) }
    var secondsLeft by remember { mutableIntStateOf(0) }
    var sessions by remember { mutableIntStateOf(prefs.getInt("sessions", 0)) }
    LaunchedEffect(runningUntil) {
        while (runningUntil > 0L) {
            val remain = ((runningUntil - System.currentTimeMillis()) / 1000L).toInt()
            if (remain <= 0) {
                runningUntil = 0L; prefs.edit().putLong("timer_until", 0L).putInt("sessions", ++sessions).apply()
                break
            }
            secondsLeft = remain
            delay(1000)
        }
        if (runningUntil == 0L) secondsLeft = 0
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Canvas, surface = Color.White)) {
        Scaffold(containerColor = Canvas, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Timer, null) }, label = { Text("Focus") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Insights, null) }, label = { Text("Insights") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Settings") })
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(14.dp), color = Ink, modifier = Modifier.size(44.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.School, null, tint = Color.White) } }
                    Spacer(Modifier.width(12.dp)); Column { Text("StudyGuard", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink); Text("Make time count", color = Muted, fontSize = 12.sp) }
                    Spacer(Modifier.weight(1f)); Icon(Icons.Default.Shield, null, tint = Accent, modifier = Modifier.size(26.dp))
                } }
                when (tab) {
                    0 -> {
                        item { Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Ink)) {
                            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (runningUntil > 0) "FOCUS SESSION" else "READY TO FOCUS", color = Color(0xFFBFC9D4), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(12.dp)); Text(if (runningUntil > 0) "%02d:%02d".format(secondsLeft / 60, secondsLeft % 60) else "%02d:00".format(duration), color = Color.White, fontSize = 54.sp, fontWeight = FontWeight.Light)
                                Text(if (runningUntil > 0) "Stay with one task at a time" else "A little progress adds up", color = Color(0xFFBFC9D4))
                                Spacer(Modifier.height(20.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(25, 45, 60).forEach { m -> FilterChip(selected = duration == m, onClick = { duration = m; prefs.edit().putInt("duration_min", m).apply() }, label = { Text("${m}m") }, enabled = runningUntil == 0L) }
                                }
                                Spacer(Modifier.height(14.dp)); Button(onClick = {
                                    if (runningUntil > 0) { runningUntil = 0L; prefs.edit().putLong("timer_until", 0L).apply() }
                                    else { runningUntil = System.currentTimeMillis() + duration * 60_000L; prefs.edit().putLong("timer_until", runningUntil).apply() }
                                }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Ink), modifier = Modifier.fillMaxWidth()) {
                                    Icon(if (runningUntil > 0) Icons.Default.Stop else Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text(if (runningUntil > 0) "End session" else "Start focus", fontWeight = FontWeight.Bold)
                                }
                            }
                        } }
                        item { Text("APP SHIELD", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        item { ShieldToggle("Instagram Reels", "Block Reels screens only", reels) { reels = it; prefs.edit().putBoolean("block_reels", it).apply() } }
                        item { ShieldToggle("YouTube Shorts", "Keep regular YouTube videos available", shorts) { shorts = it; prefs.edit().putBoolean("block_shorts", it).apply() } }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AccessibilityNew, null, tint = Accent); Spacer(Modifier.width(10.dp)); Text("Blocker permission", fontWeight = FontWeight.SemiBold, color = Ink) }
                            Text("Enable StudyGuard App Blocker in Android Accessibility settings to detect Reels and Shorts.", color = Muted, fontSize = 13.sp)
                            TextButton(onClick = onAccessibility) { Text("Open Accessibility settings") }
                        } } }
                    }
                    1 -> {
                        item { Text("Your study overview", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("Sessions", sessions.toString(), Modifier.weight(1f)); StatCard("Focus goal", "${duration} min", Modifier.weight(1f)) } }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(18.dp)) { Text("Keep your streak alive", color = Ink, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text("Completed focus sessions are counted on this device. More detailed daily and weekly charts will be added in a later release.", color = Muted, fontSize = 13.sp) } } }
                    }
                    else -> {
                        item { Text("Settings", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(16.dp)) {
                            Text("Payment Mode", color = Ink, fontWeight = FontWeight.Bold); Text("Pause screen detection for UPI payments. You must manually switch StudyGuard Accessibility OFF and ON in Android settings.", color = Muted, fontSize = 13.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) { Text("Payment Mode", modifier = Modifier.weight(1f), color = Ink); Switch(checked = payment, onCheckedChange = { enabled -> payment = enabled; prefs.edit().putBoolean("payment_mode", enabled).apply(); onAccessibility() }) }
                        } } }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(16.dp)) { Text("Accessibility service", color = Ink, fontWeight = FontWeight.Bold); Text("Android requires you to enable or disable this permission yourself. StudyGuard cannot silently change it.", color = Muted, fontSize = 13.sp); TextButton(onClick = onAccessibility) { Text("Manage permission") } } } }
                        item { TextButton(onClick = onAppDetails) { Text("Open Android app settings") } }
                    }
                }
                item { Spacer(Modifier.height(16.dp)); Text("StudyGuard runs locally. It does not read or store your messages or passwords.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 12.dp)) }
            }
        }
    }
}

@Composable private fun ShieldToggle(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0xFFEAF0F4), shape = RoundedCornerShape(12.dp), modifier = Modifier.size(42.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Shield, null, tint = Accent) } }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = Ink, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 12.sp) }
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}
@Composable private fun StatCard(label: String, value: String, modifier: Modifier) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Text(label, color = Muted, fontSize = 12.sp); Text(value, color = Ink, fontSize = 26.sp, fontWeight = FontWeight.Bold) } } }
