package com.studyguard.app

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View

/**
 * Heuristic screen detector. It only reacts to Reels/Shorts labels in the visible
 * accessibility tree; it does not block the Instagram or YouTube package wholesale.
 * App UI changes can affect detection, so validate on real devices before relying on it.
 */
class StudyGuardAccessibilityService : AccessibilityService() {
    private var blockerView: View? = null
    private var lastShownAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences("studyguard", MODE_PRIVATE)
        if (prefs.getBoolean("payment_mode", false)) return
        val pkg = event.packageName?.toString() ?: return
        val isInstagram = pkg == "com.instagram.android" && prefs.getBoolean("block_reels", true)
        val isYouTube = pkg == "com.google.android.youtube" && prefs.getBoolean("block_shorts", true)
        if (!isInstagram && !isYouTube) { removeBlocker(); return }
        val text = StringBuilder()
        collectText(rootInActiveWindow, text, 0)
        val visible = text.toString().lowercase()
        val detected = if (isInstagram) {
            visible.contains("reels") || visible.contains("reel viewer") || visible.contains("reel")
        } else {
            visible.contains("shorts") || visible.contains("short video")
        }
        if (detected) showBlocker(if (isInstagram) "Instagram Reels" else "YouTube Shorts") else removeBlocker()
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 18 || out.length > 12000) return
        node.text?.let { out.append(' ').append(it) }
        node.contentDescription?.let { out.append(' ').append(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out, depth + 1)
    }

    private fun showBlocker(label: String) {
        if (blockerView != null || System.currentTimeMillis() - lastShownAt < 1200) return
        lastShownAt = System.currentTimeMillis()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(36, 32, 36, 32)
            background = GradientDrawable().apply { setColor(Color.rgb(31, 41, 55)); cornerRadius = 42f }
        }
        panel.addView(TextView(this).apply { text = "STUDYGUARD"; setTextColor(Color.LTGRAY); textSize = 12f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD })
        panel.addView(TextView(this).apply { text = "$label is blocked"; setTextColor(Color.WHITE); textSize = 23f; gravity = Gravity.CENTER; setPadding(0, 18, 0, 10); typeface = Typeface.DEFAULT_BOLD })
        panel.addView(TextView(this).apply { text = "Back to your focus session. You can still use the rest of the app."; setTextColor(Color.LTGRAY); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 18) })
        panel.addView(Button(this).apply { text = "Go back"; setOnClickListener { performGlobalAction(GLOBAL_ACTION_BACK); removeBlocker() } })
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER; width = (resources.displayMetrics.widthPixels * .88f).toInt() }
        try { wm.addView(panel, params); blockerView = panel } catch (_: Exception) { blockerView = null }
    }

    private fun removeBlocker() {
        val view = blockerView ?: return
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view) } catch (_: Exception) { }
        blockerView = null
    }
    override fun onInterrupt() { removeBlocker() }
    override fun onDestroy() { removeBlocker(); super.onDestroy() }
}
