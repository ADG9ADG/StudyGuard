@echo off
REM Uses an installed Gradle. For a portable wrapper, run: gradle wrapper --gradle-version 8.9
gradle %*
