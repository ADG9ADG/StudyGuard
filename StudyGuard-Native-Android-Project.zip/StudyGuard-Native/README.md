# StudyGuard Native Android (starter implementation)

This is a native Kotlin + Jetpack Compose Android project based on the supplied StudyGuard web/PWA visual reference. Minimum Android 8.0 (API 26), compile/target SDK 35.

## Features in this first native pass
- Focus timer with 25/45/60-minute presets and local persistence of the deadline.
- Independent Instagram Reels and YouTube Shorts switches.
- Accessibility service that inspects visible accessibility text and shows a blocking overlay only when it finds Reels/Shorts-related labels.
- Payment Mode that opens Android Accessibility Settings; the user must manually disable/re-enable the service. It cannot silently toggle this permission.
- Basic on-device session count and insights screen.

## Important detection limitation
Reels/Shorts detection is heuristic, based on accessibility text/content descriptions exposed by Instagram and YouTube. These apps change their UI frequently and may expose ambiguous labels. This starter implementation can have false positives/negatives and must be tested on the target phone/app versions. It does not block all of Instagram or all of YouTube. Normal YouTube video playback is intended to remain available, but must be verified on-device.

## Build
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on a test device.
5. Open StudyGuard > Settings > Accessibility settings and enable **StudyGuard App Blocker**.
6. Test normal Instagram feed, Reels, YouTube home, normal videos, and Shorts separately.

## Safety and privacy
No Device Admin, no anti-uninstall, and no attempt to prevent access to Android Settings. The user remains able to disable the service or uninstall the app. Accessibility access is used only to inspect visible screen labels for the two configured target experiences.
