package com.studyguard.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class AppAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(context, "StudyGuard uninstall protection enabled", Toast.LENGTH_SHORT).show()
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence? {
        if (FocusPrefs.isStrictMode(context) && FocusPrefs.isFocusActive(context)) {
            return "Strict Mode is currently ACTIVE! Focus session is still running. You cannot uninstall or deactivate StudyGuard until the session ends."
        }
        return "Disabling device administrator will remove uninstall protection for StudyGuard."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Toast.makeText(context, "StudyGuard uninstall protection disabled", Toast.LENGTH_SHORT).show()
    }
}
