package com.studyguard.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * On-device detector for Reels, Shorts, and Strict Mode anti-tamper.
 * Only targets Instagram, YouTube, and device settings when Strict Mode is active.
 * UPI & banking apps are explicitly excluded to keep payment flows completely uninterrupted.
 */
class BlockerAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L

    companion object {
        const val PKG_INSTAGRAM = "com.instagram.android"
        const val PKG_YOUTUBE = "com.google.android.youtube"
        const val PKG_SETTINGS = "com.android.settings"
        const val PKG_INSTALLER_GOOGLE = "com.google.android.packageinstaller"
        const val PKG_INSTALLER_AOSP = "com.android.packageinstaller"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        updateServiceFilter()
    }

    /**
     * Keep target packages scoped strictly so UPI and banking apps are never monitored.
     */
    private fun updateServiceFilter() {
        val info = serviceInfo ?: AccessibilityServiceInfo()
        val strictActive = FocusPrefs.isStrictMode(this) && FocusPrefs.isFocusActive(this)

        info.packageNames = if (strictActive) {
            arrayOf(
                PKG_INSTAGRAM,
                PKG_YOUTUBE,
                PKG_SETTINGS,
                PKG_INSTALLER_GOOGLE,
                PKG_INSTALLER_AOSP
            )
        } else {
            arrayOf(PKG_INSTAGRAM, PKG_YOUTUBE)
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString() ?: return

        // 1. Anti-Uninstall / Anti-Tamper check under active Strict Mode
        val isStrictActive = FocusPrefs.isStrictMode(this) && FocusPrefs.isFocusActive(this)
        if (isStrictActive && (pkg == PKG_SETTINGS || pkg == PKG_INSTALLER_GOOGLE || pkg == PKG_INSTALLER_AOSP)) {
            checkAndPreventUninstall()
            return
        }

        // 2. Distraction blocker for Instagram & YouTube
        val isInstagram = pkg == PKG_INSTAGRAM && FocusPrefs.isInstagramEnabled(this)
        val isYouTube = pkg == PKG_YOUTUBE && FocusPrefs.isYouTubeEnabled(this)
        if (!isInstagram && !isYouTube) return

        val root = rootInActiveWindow ?: return
        val signals = ScreenSignals()
        collectSignals(root, signals, 0)

        val likelyReels = isInstagram && signals.isInstagramReelsScreen()
        val likelyShorts = isYouTube && signals.isYouTubeShortsScreen()

        if (likelyReels || likelyShorts) {
            val now = System.currentTimeMillis()
            if (now - lastBlockedAt > 1800L) {
                lastBlockedAt = now
                FocusPrefs.addBlocked(this)
                Toast.makeText(
                    this,
                    if (likelyReels) "Instagram Reels blocked" else "YouTube Shorts blocked",
                    Toast.LENGTH_SHORT
                ).show()
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
    }

    private fun checkAndPreventUninstall() {
        val root = rootInActiveWindow ?: return
        val signals = ScreenSignals()
        collectSignals(root, signals, 0)

        val hasStudyGuard = signals.hasAny(signals.allText, "studyguard", "study guard")
        val isTamperAction = signals.hasAny(
            signals.allText,
            "uninstall", "force stop", "deactivate", "clear data", "delete data"
        )

        if (hasStudyGuard && isTamperAction) {
            val now = System.currentTimeMillis()
            if (now - lastBlockedAt > 2000L) {
                lastBlockedAt = now
                Toast.makeText(
                    this,
                    "Strict Mode is ACTIVE! Focus session is in progress.",
                    Toast.LENGTH_LONG
                ).show()
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }
    }

    private fun collectSignals(node: AccessibilityNodeInfo?, signals: ScreenSignals, depth: Int) {
        if (node == null || depth > 22) return

        val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
        val description = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
        val combined = "$text $description".trim()
        if (combined.isNotBlank()) signals.allText.add(combined)

        val selected = node.isSelected || (node.parent?.isSelected == true)
        if (selected && combined.isNotBlank()) signals.selectedText.add(combined)

        for (i in 0 until node.childCount) {
            collectSignals(node.getChild(i), signals, depth + 1)
        }
    }

    private class ScreenSignals {
        val allText = mutableListOf<String>()
        val selectedText = mutableListOf<String>()

        fun hasAny(values: List<String>, vararg words: String): Boolean =
            values.any { value -> words.any { word -> value.contains(word) } }

        fun isYouTubeShortsScreen(): Boolean {
            return hasAny(
                allText,
                "shorts player",
                "shorts video",
                "create a short",
                "use this sound",
                "remix this short"
            )
        }

        fun isInstagramReelsScreen(): Boolean {
            val selectedReelsTab = hasAny(selectedText, "reels")
            val reelsViewerActions = hasAny(
                allText,
                "original audio", "use audio", "remix", "reels video"
            )
            return selectedReelsTab || reelsViewerActions
        }
    }

    override fun onInterrupt() = Unit
}
