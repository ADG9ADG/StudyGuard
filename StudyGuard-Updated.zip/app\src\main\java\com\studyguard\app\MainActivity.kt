package com.studyguard.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

private enum class StudyTab(val label: String) {
    HOME("Home"), INSTAGRAM("Instagram"), YOUTUBE("YouTube"),
    FOCUS("Focus"), REPORTS("Reports"), SETTINGS("Settings")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyGuardApp() }
    }
}

// Utility functions to check system permissions
fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val expectedService = ComponentName(context, BlockerAccessibilityService::class.java).flattenToString()
    val enabledServices = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    return enabledServices.split(":").any { it.equals(expectedService, ignoreCase = true) }
}

fun isDeviceAdminActive(context: Context): Boolean {
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
    val admin = ComponentName(context, AppAdminReceiver::class.java)
    return dpm.isAdminActive(admin)
}

@Composable
private fun StudyGuardApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(StudyTab.HOME) }
    var endTime by remember { mutableLongStateOf(FocusPrefs.endTime(context)) }
    var blocked by remember { mutableIntStateOf(FocusPrefs.blockedCount(context)) }
    var instagramOn by remember { mutableStateOf(FocusPrefs.isInstagramEnabled(context)) }
    var youtubeOn by remember { mutableStateOf(FocusPrefs.isYouTubeEnabled(context)) }
    var strictMode by remember { mutableStateOf(FocusPrefs.isStrictMode(context)) }
    var selectedMinutes by remember { mutableIntStateOf(45) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    var accessibilityGranted by remember { mutableStateOf(isAccessibilityServiceEnabled(context)) }
    var deviceAdminGranted by remember { mutableStateOf(isDeviceAdminActive(context)) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            endTime = FocusPrefs.endTime(context)
            blocked = FocusPrefs.blockedCount(context)
            accessibilityGranted = isAccessibilityServiceEnabled(context)
            deviceAdminGranted = isDeviceAdminActive(context)

            if (endTime > 0L && now >= endTime) {
                FocusPrefs.stop(context)
                endTime = 0L
            }
            delay(1000)
        }
    }

    val active = endTime > now
    val remaining = if (active) endTime - now else 0L
    val mins = TimeUnit.MILLISECONDS.toMinutes(remaining)
    val secs = TimeUnit.MILLISECONDS.toSeconds(remaining) % 60

    val primaryColor = Color(0xFF3F51B5)
    val successColor = Color(0xFF10B981)
    val warningColor = Color(0xFFF59E0B)

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = primaryColor,
            onPrimary = Color.White,
            secondary = Color(0xFF6366F1),
            background = Color(0xFFF8FAFC),
            surface = Color.White,
            surfaceVariant = Color(0xFFF1F5F9),
            onSurface = Color(0xFF0F172A),
            onSurfaceVariant = Color(0xFF64748B)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp
                ) {
                    StudyTab.values().forEach { item ->
                        val icon = when (item) {
                            StudyTab.HOME -> Icons.Outlined.Home
                            StudyTab.INSTAGRAM -> Icons.Outlined.VideoLibrary
                            StudyTab.YOUTUBE -> Icons.Outlined.SmartDisplay
                            StudyTab.FOCUS -> Icons.Outlined.Timer
                            StudyTab.REPORTS -> Icons.Outlined.Assessment
                            StudyTab.SETTINGS -> Icons.Outlined.Settings
                        }
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(icon, contentDescription = item.label) },
                            label = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "STUDYGUARD",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = primaryColor,
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            tab.label,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (active) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFEEF2FF),
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(successColor, CircleShape)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "Session Active",
                                    color = primaryColor,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // System Health Banner (Accessibility & UPI Safe)
                HealthStatusCard(
                    accessibilityGranted = accessibilityGranted,
                    upiSafe = true,
                    strictAdminGranted = deviceAdminGranted,
                    strictMode = strictMode,
                    onOpenAccessibility = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    onOpenDeviceAdmin = {
                        val adminComponent = ComponentName(context, AppAdminReceiver::class.java)
                        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                            putExtra(
                                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                "Activate StudyGuard Device Admin to prevent uninstalling while Strict Focus Mode is active."
                            )
                        }
                        context.startActivity(intent)
                    }
                )

                when (tab) {
                    StudyTab.HOME -> HomePage(
                        active = active,
                        mins = mins,
                        secs = secs,
                        blocked = blocked,
                        instagramOn = instagramOn,
                        youtubeOn = youtubeOn,
                        selectedMinutes = selectedMinutes,
                        onMinutes = { selectedMinutes = it },
                        onStart = {
                            FocusPrefs.start(context, selectedMinutes)
                            endTime = FocusPrefs.endTime(context)
                        },
                        onEnd = {
                            if (!strictMode) {
                                FocusPrefs.stop(context)
                                endTime = 0L
                            } else {
                                Toast.makeText(context, "Strict Mode is on: cannot end session early!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onOpenInstagram = { tab = StudyTab.INSTAGRAM },
                        onOpenYouTube = { tab = StudyTab.YOUTUBE },
                        onOpenFocus = { tab = StudyTab.FOCUS }
                    )
                    StudyTab.INSTAGRAM -> BlockerPage(
                        title = "Instagram Reels",
                        subtitle = "Blocks short-form Reels to protect study flow, leaving messages and feeds intact.",
                        enabled = instagramOn,
                        onEnabledChange = {
                            instagramOn = it
                            FocusPrefs.setInstagramEnabled(context, it)
                        },
                        appName = "Instagram"
                    )
                    StudyTab.YOUTUBE -> BlockerPage(
                        title = "YouTube Shorts",
                        subtitle = "Blocks distracting Shorts while allowing educational long-form videos.",
                        enabled = youtubeOn,
                        onEnabledChange = {
                            youtubeOn = it
                            FocusPrefs.setYouTubeEnabled(context, it)
                        },
                        appName = "YouTube"
                    )
                    StudyTab.FOCUS -> FocusPage(
                        active = active,
                        mins = mins,
                        secs = secs,
                        selectedMinutes = selectedMinutes,
                        onMinutes = { selectedMinutes = it },
                        strictMode = strictMode,
                        onStart = {
                            FocusPrefs.start(context, selectedMinutes)
                            endTime = FocusPrefs.endTime(context)
                        },
                        onEnd = {
                            if (!strictMode) {
                                FocusPrefs.stop(context)
                                endTime = 0L
                            } else {
                                Toast.makeText(context, "Strict Mode is ON! Session cannot be stopped.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                    StudyTab.REPORTS -> ReportsPage(blocked = blocked, active = active)
                    StudyTab.SETTINGS -> SettingsPage(
                        strictMode = strictMode,
                        deviceAdminGranted = deviceAdminGranted,
                        accessibilityGranted = accessibilityGranted,
                        onStrictChange = { newVal ->
                            strictMode = newVal
                            FocusPrefs.setStrictMode(context, newVal)

                            if (newVal && !deviceAdminGranted) {
                                val adminComponent = ComponentName(context, AppAdminReceiver::class.java)
                                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                                    putExtra(
                                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                        "Enable device administrator so StudyGuard cannot be uninstalled during strict mode."
                                    )
                                }
                                context.startActivity(intent)
                            }
                        },
                        onAccessibility = {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                        onDeviceAdmin = {
                            val adminComponent = ComponentName(context, AppAdminReceiver::class.java)
                            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                                putExtra(
                                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                    "Enable device administrator so StudyGuard cannot be uninstalled during strict mode."
                                )
                            }
                            context.startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HealthStatusCard(
    accessibilityGranted: Boolean,
    upiSafe: Boolean,
    strictAdminGranted: Boolean,
    strictMode: Boolean,
    onOpenAccessibility: () -> Unit,
    onOpenDeviceAdmin: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "SYSTEM STATUS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // 1. UPI Payment Status Badge
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "UPI Safe",
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "UPI & Banking: Safe",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "Only Instagram & YouTube are monitored. UPI apps are shielded.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFE2E8F0))

            // 2. Accessibility Service Status
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (accessibilityGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (accessibilityGranted) Color(0xFF10B981) else Color(0xFFF59E0B),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (accessibilityGranted) "Blocker Service Active" else "Accessibility Permission Required",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (!accessibilityGranted) {
                        Text(
                            "Required to detect Reels and Shorts screens.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (!accessibilityGranted) {
                    FilledTonalButton(
                        onClick = onOpenAccessibility,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text("Enable", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            // 3. Strict Mode / Anti-Uninstall Status
            if (strictMode) {
                HorizontalDivider(color = Color(0xFFE2E8F0))
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (strictAdminGranted) Icons.Default.Lock else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (strictAdminGranted) Color(0xFF6366F1) else Color(0xFFF59E0B),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (strictAdminGranted) "Anti-Uninstall Protected" else "Admin Access Required",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            if (strictAdminGranted) "App cannot be uninstalled during focus sessions"
                            else "Activate device admin to lock uninstall",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (!strictAdminGranted) {
                        FilledTonalButton(
                            onClick = onOpenDeviceAdmin,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text("Activate", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomePage(
    active: Boolean, mins: Long, secs: Long, blocked: Int,
    instagramOn: Boolean, youtubeOn: Boolean,
    selectedMinutes: Int, onMinutes: (Int) -> Unit,
    onStart: () -> Unit, onEnd: () -> Unit,
    onOpenInstagram: () -> Unit, onOpenYouTube: () -> Unit, onOpenFocus: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(22.dp)) {
            Text(
                if (active) "CURRENT FOCUS SESSION" else "FOCUS TIMER",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (active) "%02d:%02d".format(mins, secs) else "Protect your attention",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                "Shorts & Reels blockers operate in background. Start timer for timed study.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(18.dp))
            if (active) {
                OutlinedButton(
                    onClick = onEnd,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("End Focus Session")
                }
            } else {
                DurationChoices(selectedMinutes, onMinutes)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onStart,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Start $selectedMinutes-Min Focus", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    Text(
        "ACTIVE BLOCKERS",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    BlockerSummaryCard("Instagram Reels", instagramOn, "Blocks short video player", onOpenInstagram)
    BlockerSummaryCard("YouTube Shorts", youtubeOn, "Blocks shorts feed & viewer", onOpenYouTube)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Total Distractions Prevented",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    "$blocked",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            OutlinedButton(onClick = onOpenFocus, shape = RoundedCornerShape(10.dp)) {
                Text("Session details")
            }
        }
    }
}

@Composable
private fun BlockerSummaryCard(title: String, enabled: Boolean, detail: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                Text(
                    detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (enabled) Color(0xFFDCFCE7) else Color(0xFFF1F5F9)
            ) {
                Text(
                    if (enabled) "ENABLED" else "DISABLED",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (enabled) Color(0xFF166534) else Color(0xFF64748B)
                )
            }
        }
    }
}

@Composable
private fun BlockerPage(
    title: String, subtitle: String, enabled: Boolean, onEnabledChange: (Boolean) -> Unit,
    appName: String
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                if (enabled) "BLOCKER ACTIVE" else "BLOCKER INACTIVE",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (enabled) Color(0xFF10B981) else Color(0xFF94A3B8)
            )
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            HorizontalDivider(color = Color(0xFFF1F5F9))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Block $appName short videos", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Closes reels/shorts immediately upon detection",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = enabled, onCheckedChange = onEnabledChange)
            }
        }
    }
    InfoCard(
        "Works Anywhere",
        "Shorts and Reels detection works seamlessly whenever you use $appName. The timer is optional."
    )
    InfoCard(
        "Regular Content Remains Available",
        "Direct messages, normal video searches, long videos, and feed photos are not blocked. Only short-video loops are blocked."
    )
}

@Composable
private fun FocusPage(
    active: Boolean, mins: Long, secs: Long, selectedMinutes: Int,
    onMinutes: (Int) -> Unit, strictMode: Boolean, onStart: () -> Unit, onEnd: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                if (active) "SESSION RUNNING" else "CUSTOM FOCUS SESSION",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                if (active) "%02d:%02d".format(mins, secs) else "Set your focus target",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold
            )
            if (active) {
                Text(
                    if (strictMode) "Strict Mode is active: Early cancellation is locked to enforce commitment."
                    else "Focus timer in progress. Stay concentrated until completion.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (!strictMode) {
                    OutlinedButton(onClick = onEnd, modifier = Modifier.fillMaxWidth()) {
                        Text("End session")
                    }
                }
            } else {
                DurationChoices(selectedMinutes, onMinutes)
                Button(
                    onClick = onStart,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Start Focus Session", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    InfoCard(
        "Strict Mode Protection",
        "When Strict Mode is enabled, the 'End session' button is disabled, and StudyGuard cannot be uninstalled until the countdown completes."
    )
}

@Composable
private fun DurationChoices(selected: Int, onSelected: (Int) -> Unit) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
    ) {
        listOf(15, 25, 45, 60, 90, 120).forEach { value ->
            FilterChip(
                selected = selected == value,
                onClick = { onSelected(value) },
                label = { Text("$value min") },
                shape = RoundedCornerShape(10.dp)
            )
        }
    }
}

@Composable
private fun ReportsPage(blocked: Int, active: Boolean) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(22.dp)) {
            Text(
                "TOTAL SCREENS PREVENTED",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "$blocked",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF3F51B5)
            )
            Text("Reels and Shorts prevented on this device.")
        }
    }
    InfoCard(
        "Current Session",
        if (active) "A focus session is currently in progress." else "No active timer. Background blockers remain active."
    )
}

@Composable
private fun SettingsPage(
    strictMode: Boolean,
    deviceAdminGranted: Boolean,
    accessibilityGranted: Boolean,
    onStrictChange: (Boolean) -> Unit,
    onAccessibility: () -> Unit,
    onDeviceAdmin: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Strict Mode Toggle
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Strict Mode (Anti-Uninstall)", fontWeight = FontWeight.Bold)
                    Text(
                        "Disables the end-session button and prevents uninstalling while a session is active.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = strictMode, onCheckedChange = onStrictChange)
            }

            if (strictMode && !deviceAdminGranted) {
                OutlinedButton(
                    onClick = onDeviceAdmin,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Activate Device Admin Permission")
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Accessibility Permission
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Accessibility Service", fontWeight = FontWeight.Bold)
                Text(
                    if (accessibilityGranted) "Service is currently active and protecting your screen."
                    else "Required to recognize Reels and Shorts patterns.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = onAccessibility,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (accessibilityGranted) "Manage Accessibility" else "Enable Accessibility Service")
                }
            }
        }
    }

    InfoCard(
        "UPI & Banking Safety Guarantee",
        "StudyGuard is configured to strictly monitor ONLY Instagram and YouTube. It is not attached to PhonePe, Google Pay, Paytm, or bank applications, keeping your UPI payments secure and uninterrupted."
    )

    InfoCard(
        "Anti-Uninstall Mechanism",
        "When Strict Mode is ON and a focus session is running, StudyGuard is registered as a Device Administrator. The system blocks attempts to remove the application until your timer expires."
    )
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Text(
                body,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
